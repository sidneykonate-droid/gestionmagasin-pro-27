package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.MagasinDatabase
import com.example.data.entity.ArticleEntity
import com.example.data.entity.ExportHistoryEntity
import com.example.data.entity.VenteTicketEntity
import com.example.data.model.FormatUtils
import com.example.data.model.MagasinsOrca
import com.example.data.repository.MagasinRepository
import com.example.export.DocumentExporter
import com.example.export.RapportKpiSummary
import com.example.notifications.InventoryReminderScheduler
import com.example.notifications.OrcaNotificationHelper
import com.example.notifications.ReminderPreferences
import com.example.scanner.TicketReceiptAnalyzer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar
import java.util.Locale

enum class PeriodeFiltre(val label: String) {
    AUJOURD_HUI("Aujourd'hui"),
    CETTE_SEMAINE("Cette semaine"),
    CE_MOIS("Ce mois"),
    TOUT_HISTORIQUE("Tout l'historique"),
    DATE_PRECISE_LONGUE_DATE("Date précise / Longue date")
}

data class OcrFormState(
    val editingId: Long = 0L,
    val codeBarre: String = "",
    val reference: String = "",
    val designation: String = "",
    val prixFcfaText: String = "",
    val quantiteText: String = "1",
    val magasin: String = MagasinsOrca.MARCORY,
    val scanInfoMessage: String? = null,
    val existingMatchFound: Boolean = false
)

data class RapportsFilterState(
    val periode: PeriodeFiltre = PeriodeFiltre.CE_MOIS,
    val magasin: String = MagasinsOrca.TOUS_LES_SITES,
    val produitQuery: String = "",
    val customStartMillis: Long = MagasinViewModel.defaultMultiYearStartMillis(),
    val customEndMillis: Long = MagasinViewModel.endOfDayMillis(System.currentTimeMillis())
)

data class PendingTicketValidation(
    val codeBarre: String,
    val reference: String,
    val designation: String,
    val quantiteVendueText: String,
    val prixUnitaireFcfaText: String,
    val montantTotalFcfaText: String,
    val dateVenteTimestamp: Long,
    val numeroTicket: String,
    val magasin: String,
    val matchedArticle: ArticleEntity? = null,
    val rawOcrText: String = "",
    val dateAutoDetectee: Boolean = false
)

data class MonthlySalesPoint(
    val yearMonthKey: String,
    val label: String,
    val totalFcfa: Long,
    val quantite: Int,
    val ticketCount: Int
)

class MagasinViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MagasinDatabase.getInstance(application)
    private val repository = MagasinRepository(database)

    val allArticles: StateFlow<List<ArticleEntity>> = repository.allArticles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVentes: StateFlow<List<VenteTicketEntity>> = repository.allVentes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExports: StateFlow<List<ExportHistoryEntity>> = repository.allExports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _ocrFormState = MutableStateFlow(OcrFormState())
    val ocrFormState: StateFlow<OcrFormState> = _ocrFormState.asStateFlow()

    private val _baseSearchQuery = MutableStateFlow("")
    val baseSearchQuery: StateFlow<String> = _baseSearchQuery.asStateFlow()

    private val _baseMagasinFilter = MutableStateFlow(MagasinsOrca.TOUS_LES_SITES)
    val baseMagasinFilter: StateFlow<String> = _baseMagasinFilter.asStateFlow()

    private val _etiquettesMagasinFilter = MutableStateFlow(MagasinsOrca.TOUS_LES_SITES)
    val etiquettesMagasinFilter: StateFlow<String> = _etiquettesMagasinFilter.asStateFlow()

    private val _etiquettesSelectedIds = MutableStateFlow<Set<Long>>(emptySet())
    val etiquettesSelectedIds: StateFlow<Set<Long>> = _etiquettesSelectedIds.asStateFlow()

    private val _rapportsFilter = MutableStateFlow(RapportsFilterState())
    val rapportsFilter: StateFlow<RapportsFilterState> = _rapportsFilter.asStateFlow()

    private val _pendingTicket = MutableStateFlow<PendingTicketValidation?>(null)
    val pendingTicket: StateFlow<PendingTicketValidation?> = _pendingTicket.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _reminderPrefs = MutableStateFlow(
        InventoryReminderScheduler.loadPreferences(application)
    )
    val reminderPrefs: StateFlow<ReminderPreferences> = _reminderPrefs.asStateFlow()

    val lowStockArticles: StateFlow<List<ArticleEntity>> = combine(
        allArticles,
        _reminderPrefs
    ) { articles, prefs ->
        articles.filter { it.quantite <= prefs.lowStockThreshold }
            .sortedBy { it.quantite }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredBaseArticles: StateFlow<List<ArticleEntity>> = combine(
        allArticles,
        _baseSearchQuery,
        _baseMagasinFilter
    ) { articles, query, magasin ->
        val q = query.trim().lowercase(Locale.FRANCE)
        articles.filter { article ->
            val matchMagasin = magasin == MagasinsOrca.TOUS_LES_SITES || article.magasin == magasin
            val matchQuery = q.isEmpty() ||
                article.codeBarre.lowercase(Locale.FRANCE).contains(q) ||
                article.reference.lowercase(Locale.FRANCE).contains(q) ||
                article.designation.lowercase(Locale.FRANCE).contains(q)
            matchMagasin && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredEtiquettesArticles: StateFlow<List<ArticleEntity>> = combine(
        allArticles,
        _etiquettesMagasinFilter
    ) { articles, magasin ->
        if (magasin == MagasinsOrca.TOUS_LES_SITES) articles
        else articles.filter { it.magasin == magasin }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredRapportsVentes: StateFlow<List<VenteTicketEntity>> = combine(
        allVentes,
        _rapportsFilter
    ) { ventes, filter ->
        val (startMs, endMs) = resolvePeriodBounds(filter)
        val q = filter.produitQuery.trim().lowercase(Locale.FRANCE)
        ventes.filter { vente ->
            val matchDate = vente.dateVenteTimestamp in startMs..endMs
            val matchMagasin = filter.magasin == MagasinsOrca.TOUS_LES_SITES ||
                vente.magasin == filter.magasin
            val matchProduit = q.isEmpty() ||
                vente.codeBarre.lowercase(Locale.FRANCE).contains(q) ||
                vente.reference.lowercase(Locale.FRANCE).contains(q) ||
                vente.designation.lowercase(Locale.FRANCE).contains(q) ||
                vente.numeroTicket.lowercase(Locale.FRANCE).contains(q)
            matchDate && matchMagasin && matchProduit
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rapportKpi: StateFlow<RapportKpiSummary> = combine(
        filteredRapportsVentes,
        allArticles,
        _rapportsFilter
    ) { ventes, articles, filter ->
        val q = filter.produitQuery.trim().lowercase(Locale.FRANCE)
        val stockFiltre = articles.filter { article ->
            val matchMagasin = filter.magasin == MagasinsOrca.TOUS_LES_SITES ||
                article.magasin == filter.magasin
            val matchProduit = q.isEmpty() ||
                article.codeBarre.lowercase(Locale.FRANCE).contains(q) ||
                article.reference.lowercase(Locale.FRANCE).contains(q) ||
                article.designation.lowercase(Locale.FRANCE).contains(q)
            matchMagasin && matchProduit
        }
        RapportKpiSummary(
            quantiteTotaleVendue = ventes.sumOf { it.quantiteVendue },
            chiffreAffairesFcfa = ventes.sumOf { it.montantTotalFcfa },
            valorisationStockFcfa = stockFiltre.sumOf { it.prixFcfa * it.quantite },
            nombreTickets = ventes.size
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        RapportKpiSummary(0, 0L, 0L, 0)
    )

    val monthlySalesPoints: StateFlow<List<MonthlySalesPoint>> = filteredRapportsVentes
        .combine(_rapportsFilter) { ventes, _ ->
            val keyFormatter = java.text.SimpleDateFormat("yyyy-MM", Locale.US)
            val labelFormatter = java.text.SimpleDateFormat("MMM yy", Locale.FRANCE)
            ventes
                .groupBy { keyFormatter.format(java.util.Date(it.dateVenteTimestamp)) }
                .entries
                .sortedBy { it.key }
                .map { (key, list) ->
                    val sampleTs = list.first().dateVenteTimestamp
                    val rawLabel = labelFormatter.format(java.util.Date(sampleTs))
                        .replaceFirstChar { ch -> ch.titlecase(Locale.FRANCE) }
                    MonthlySalesPoint(
                        yearMonthKey = key,
                        label = rawLabel,
                        totalFcfa = list.sumOf { it.montantTotalFcfa },
                        quantite = list.sumOf { it.quantiteVendue },
                        ticketCount = list.size
                    )
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }

    // --- ONGLET 1 : OCR / SAISIE ---

    fun updateOcrForm(
        codeBarre: String? = null,
        reference: String? = null,
        designation: String? = null,
        prixFcfaText: String? = null,
        quantiteText: String? = null,
        magasin: String? = null
    ) {
        _ocrFormState.update { current ->
            current.copy(
                codeBarre = codeBarre ?: current.codeBarre,
                reference = reference ?: current.reference,
                designation = designation ?: current.designation,
                prixFcfaText = prixFcfaText ?: current.prixFcfaText,
                quantiteText = quantiteText ?: current.quantiteText,
                magasin = magasin ?: current.magasin
            )
        }
    }

    fun rechercherInstantaneParCodeBarre(codeBarre: String? = null) {
        val targetCode = (codeBarre ?: _ocrFormState.value.codeBarre).trim()
        if (targetCode.isEmpty()) {
            _snackbarMessage.value = "Saisissez ou scannez un code-barres pour rechercher."
            return
        }
        viewModelScope.launch {
            val found = repository.findArticleByCodeBarreAndMagasin(
                targetCode,
                _ocrFormState.value.magasin
            )
            if (found != null) {
                _ocrFormState.value = OcrFormState(
                    editingId = found.id,
                    codeBarre = found.codeBarre,
                    reference = found.reference,
                    designation = found.designation,
                    prixFcfaText = found.prixFcfa.toString(),
                    quantiteText = found.quantite.toString(),
                    magasin = found.magasin,
                    scanInfoMessage = "Article trouvé en base (${found.magasin}) — prêt pour mise à jour.",
                    existingMatchFound = true
                )
            } else {
                _ocrFormState.update {
                    it.copy(
                        editingId = 0L,
                        existingMatchFound = false,
                        scanInfoMessage = "Aucun article existant pour $targetCode. Nouvel enregistrement."
                    )
                }
            }
        }
    }

    fun analyzeArticleBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val result = withContext(Dispatchers.Default) {
                    TicketReceiptAnalyzer.analyzeProductBitmap(bitmap)
                }
                val existing = if (result.codeBarre.isNotBlank()) {
                    repository.findArticleByCodeBarreAndMagasin(
                        result.codeBarre,
                        _ocrFormState.value.magasin
                    )
                } else null

                if (existing != null) {
                    _ocrFormState.value = OcrFormState(
                        editingId = existing.id,
                        codeBarre = existing.codeBarre,
                        reference = existing.reference,
                        designation = existing.designation,
                        prixFcfaText = (result.prixFcfa ?: existing.prixFcfa).toString(),
                        quantiteText = existing.quantite.toString(),
                        magasin = existing.magasin,
                        scanInfoMessage = "OCR + Code-barres détecté : article existant chargé.",
                        existingMatchFound = true
                    )
                } else {
                    _ocrFormState.update { current ->
                        current.copy(
                            editingId = 0L,
                            codeBarre = result.codeBarre.ifBlank { current.codeBarre },
                            reference = result.reference.ifBlank { current.reference },
                            designation = result.designation.ifBlank { current.designation },
                            prixFcfaText = result.prixFcfa?.toString() ?: current.prixFcfaText,
                            existingMatchFound = false,
                            scanInfoMessage = if (result.codeBarre.isNotBlank() || result.designation.isNotBlank()) {
                                "Champs pré-remplis par ML Kit OCR. Vérifiez avant d'enregistrer."
                            } else {
                                "Texte peu lisible, complétez manuellement les champs."
                            }
                        )
                    }
                }
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur analyse OCR : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun enregistrerArticle() {
        val state = _ocrFormState.value
        val code = state.codeBarre.trim()
        val ref = state.reference.trim()
        val desig = state.designation.trim()
        val prix = state.prixFcfaText.replace(" ", "").toLongOrNull()
        val qty = state.quantiteText.replace(" ", "").toIntOrNull()

        when {
            code.isEmpty() && ref.isEmpty() -> {
                _snackbarMessage.value = "Veuillez saisir au moins un code-barres ou une référence."
                return
            }
            desig.isEmpty() -> {
                _snackbarMessage.value = "Veuillez saisir la désignation de l'article."
                return
            }
            prix == null || prix < 0L -> {
                _snackbarMessage.value = "Prix FCFA invalide."
                return
            }
            qty == null || qty < 0 -> {
                _snackbarMessage.value = "Quantité invalide."
                return
            }
        }

        viewModelScope.launch {
            val article = ArticleEntity(
                id = state.editingId,
                codeBarre = code.ifEmpty { ref },
                reference = ref.ifEmpty { code },
                designation = desig,
                prixFcfa = prix,
                quantite = qty,
                magasin = state.magasin,
                dateMaj = System.currentTimeMillis()
            )
            repository.saveArticle(article)
            val action = if (state.editingId > 0L) "mis à jour" else "enregistré"
            _ocrFormState.value = OcrFormState(magasin = state.magasin)
            _snackbarMessage.value = "Article « ${article.designation} » $action (${article.magasin})."
            triggerLowStockAlertIfNeeded(article)
        }
    }

    fun resetOcrForm() {
        _ocrFormState.value = OcrFormState(magasin = _ocrFormState.value.magasin)
    }

    // --- ONGLET 2 : BASE ARTICLES ---

    fun updateBaseSearchQuery(query: String) {
        _baseSearchQuery.value = query
    }

    fun updateBaseMagasinFilter(magasin: String) {
        _baseMagasinFilter.value = magasin
    }

    fun chargerArticleDansFormulaire(article: ArticleEntity) {
        _ocrFormState.value = OcrFormState(
            editingId = article.id,
            codeBarre = article.codeBarre,
            reference = article.reference,
            designation = article.designation,
            prixFcfaText = article.prixFcfa.toString(),
            quantiteText = article.quantite.toString(),
            magasin = article.magasin,
            scanInfoMessage = "Mode édition : ${article.designation}",
            existingMatchFound = true
        )
    }

    fun sauvegarderArticleModifie(article: ArticleEntity) {
        viewModelScope.launch {
            repository.saveArticle(article)
            _snackbarMessage.value = "Article « ${article.designation} » modifié."
            triggerLowStockAlertIfNeeded(article)
        }
    }

    fun supprimerArticle(article: ArticleEntity) {
        viewModelScope.launch {
            repository.deleteArticle(article)
            _etiquettesSelectedIds.update { it - article.id }
            _snackbarMessage.value = "Article « ${article.designation} » supprimé."
        }
    }

    // --- ONGLET 3 : ÉTIQUETTES & EXPORTS ---

    fun updateEtiquettesMagasinFilter(magasin: String) {
        _etiquettesMagasinFilter.value = magasin
    }

    fun toggleEtiquetteArticleSelection(articleId: Long) {
        _etiquettesSelectedIds.update { current ->
            if (articleId in current) current - articleId else current + articleId
        }
    }

    fun selectAllFilteredEtiquettes() {
        _etiquettesSelectedIds.value = filteredEtiquettesArticles.value.map { it.id }.toSet()
    }

    fun clearEtiquettesSelection() {
        _etiquettesSelectedIds.value = emptySet()
    }

    fun exporterPlancheDocx(context: Context) {
        val articlesToExport = resolveArticlesForExport()
        if (articlesToExport.isEmpty()) {
            _snackbarMessage.value = "Aucun article disponible pour générer la planche Word."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val magasin = _etiquettesMagasinFilter.value
                val result = DocumentExporter.exporterPlancheEtiquettesDocx(
                    context = context,
                    articles = articlesToExport,
                    magasinFiltre = magasin
                )
                repository.logExport(
                    ExportHistoryEntity(
                        typeExport = result.typeExport,
                        nomFichier = result.fileName,
                        cheminFichier = result.file.absolutePath,
                        nombreElements = result.nombreElements,
                        magasinFiltre = magasin
                    )
                )
                DocumentExporter.shareFileWithFileProvider(context, result.file, result.mimeType)
                _snackbarMessage.value = "Planche Word RVOITURE générée (${result.nombreElements} étiquettes)."
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur export Word : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun exporterClasseurXlsx(context: Context) {
        val articlesToExport = resolveArticlesForExport()
        if (articlesToExport.isEmpty()) {
            _snackbarMessage.value = "Aucun article disponible pour l'export Excel."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val magasin = _etiquettesMagasinFilter.value
                val result = DocumentExporter.exporterClasseurExcelXlsx(
                    context = context,
                    articles = articlesToExport,
                    magasinFiltre = magasin
                )
                repository.logExport(
                    ExportHistoryEntity(
                        typeExport = result.typeExport,
                        nomFichier = result.fileName,
                        cheminFichier = result.file.absolutePath,
                        nombreElements = result.nombreElements,
                        magasinFiltre = magasin
                    )
                )
                DocumentExporter.shareFileWithFileProvider(context, result.file, result.mimeType)
                _snackbarMessage.value = "Classeur Excel généré (${result.nombreElements} articles)."
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur export Excel : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun repartagerExport(context: Context, history: ExportHistoryEntity) {
        val file = File(history.cheminFichier)
        if (!file.exists()) {
            _snackbarMessage.value = "Le fichier ${history.nomFichier} n'est plus disponible en cache."
            return
        }
        val mime = when (history.typeExport) {
            "DOCX" -> DocumentExporter.MIME_DOCX
            "XLSX" -> DocumentExporter.MIME_XLSX
            else -> DocumentExporter.MIME_PDF
        }
        DocumentExporter.shareFileWithFileProvider(context, file, mime)
    }

    private fun resolveArticlesForExport(): List<ArticleEntity> {
        val filtered = filteredEtiquettesArticles.value
        val selected = _etiquettesSelectedIds.value
        return if (selected.isEmpty()) filtered
        else filtered.filter { it.id in selected }.ifEmpty { filtered }
    }

    // --- ONGLET 4 : RAPPORTS & LECTURE TICKETS ---

    fun updateRapportsPeriode(periode: PeriodeFiltre) {
        _rapportsFilter.update { it.copy(periode = periode) }
    }

    fun updateRapportsCustomStart(startMillis: Long) {
        _rapportsFilter.update { current ->
            val start = startOfDayMillis(startMillis)
            val end = maxOf(current.customEndMillis, endOfDayMillis(start))
            current.copy(
                periode = PeriodeFiltre.DATE_PRECISE_LONGUE_DATE,
                customStartMillis = start,
                customEndMillis = end
            )
        }
    }

    fun updateRapportsCustomEnd(endMillis: Long) {
        _rapportsFilter.update { current ->
            val end = endOfDayMillis(endMillis)
            val start = minOf(current.customStartMillis, startOfDayMillis(end))
            current.copy(
                periode = PeriodeFiltre.DATE_PRECISE_LONGUE_DATE,
                customStartMillis = start,
                customEndMillis = end
            )
        }
    }

    fun updateRapportsMagasin(magasin: String) {
        _rapportsFilter.update { it.copy(magasin = magasin) }
    }

    fun updateRapportsProduitQuery(query: String) {
        _rapportsFilter.update { it.copy(produitQuery = query) }
    }

    fun analyzeTicketBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val result = withContext(Dispatchers.Default) {
                    TicketReceiptAnalyzer.analyzeTicketBitmap(bitmap)
                }
                preparePendingTicketValidation(result)
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur lecture ticket : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun analyzeTicketUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val result = withContext(Dispatchers.IO) {
                    TicketReceiptAnalyzer.analyzeTicketUri(context, uri)
                }
                preparePendingTicketValidation(result)
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur lecture photo ticket : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    private suspend fun preparePendingTicketValidation(result: com.example.scanner.TicketReceiptResult) {
        val defaultSite = _rapportsFilter.value.magasin.takeIf { it != MagasinsOrca.TOUS_LES_SITES }
            ?: MagasinsOrca.MARCORY

        val matched = if (result.codeBarre.isNotBlank()) {
            repository.findArticleByCodeBarreAndMagasin(result.codeBarre, defaultSite)
        } else null

        val qty = result.quantiteDetectee.coerceAtLeast(1)
        val unitPrice = matched?.prixFcfa ?: (result.montantTotalFcfa?.div(qty) ?: 0L)
        val totalAmount = result.montantTotalFcfa ?: (unitPrice * qty)

        _pendingTicket.value = PendingTicketValidation(
            codeBarre = result.codeBarre.ifBlank { matched?.codeBarre.orEmpty() },
            reference = matched?.reference.orEmpty(),
            designation = matched?.designation ?: "Article ticket ORCA DECO",
            quantiteVendueText = qty.toString(),
            prixUnitaireFcfaText = unitPrice.toString(),
            montantTotalFcfaText = totalAmount.toString(),
            dateVenteTimestamp = result.dateVenteTimestamp,
            numeroTicket = result.numeroTicket,
            magasin = matched?.magasin ?: defaultSite,
            matchedArticle = matched,
            rawOcrText = result.rawText,
            dateAutoDetectee = result.dateDetecteeTexte.isNotBlank()
        )
    }

    fun updatePendingTicket(transform: (PendingTicketValidation) -> PendingTicketValidation) {
        _pendingTicket.update { current -> current?.let(transform) }
    }

    fun lookupArticleForPendingTicket(codeBarre: String) {
        viewModelScope.launch {
            val current = _pendingTicket.value ?: return@launch
            val matched = repository.findArticleByCodeBarreAndMagasin(codeBarre, current.magasin)
            if (matched != null) {
                val qty = current.quantiteVendueText.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val total = matched.prixFcfa * qty
                _pendingTicket.value = current.copy(
                    codeBarre = matched.codeBarre,
                    reference = matched.reference,
                    designation = matched.designation,
                    prixUnitaireFcfaText = matched.prixFcfa.toString(),
                    montantTotalFcfaText = if (current.montantTotalFcfaText.toLongOrNull() ?: 0L > 0L) {
                        current.montantTotalFcfaText
                    } else {
                        total.toString()
                    },
                    magasin = matched.magasin,
                    matchedArticle = matched
                )
            } else {
                _pendingTicket.value = current.copy(
                    codeBarre = codeBarre,
                    matchedArticle = null
                )
            }
        }
    }

    fun associerArticleAuTicket(article: ArticleEntity) {
        _pendingTicket.update { current ->
            current?.let {
                val qty = it.quantiteVendueText.toIntOrNull()?.coerceAtLeast(1) ?: 1
                it.copy(
                    codeBarre = article.codeBarre,
                    reference = article.reference,
                    designation = article.designation,
                    prixUnitaireFcfaText = article.prixFcfa.toString(),
                    montantTotalFcfaText = (article.prixFcfa * qty).toString(),
                    magasin = article.magasin,
                    matchedArticle = article
                )
            }
        }
    }

    fun confirmerValidationTicket() {
        val pending = _pendingTicket.value ?: return
        val qty = pending.quantiteVendueText.replace(" ", "").toIntOrNull()
        val unitPrice = pending.prixUnitaireFcfaText.replace(" ", "").toLongOrNull() ?: 0L
        val totalAmount = pending.montantTotalFcfaText.replace(" ", "").toLongOrNull()
            ?: (unitPrice * (qty ?: 1))

        if (pending.designation.isBlank()) {
            _snackbarMessage.value = "Veuillez renseigner ou associer un article."
            return
        }
        if (qty == null || qty <= 0) {
            _snackbarMessage.value = "La quantité vendue doit être supérieure à 0."
            return
        }

        viewModelScope.launch {
            val vente = VenteTicketEntity(
                codeBarre = pending.codeBarre.trim(),
                reference = pending.reference.trim(),
                designation = pending.designation.trim(),
                quantiteVendue = qty,
                prixUnitaireFcfa = unitPrice,
                montantTotalFcfa = totalAmount,
                dateVenteTimestamp = pending.dateVenteTimestamp,
                numeroTicket = pending.numeroTicket.trim().ifEmpty { "TKT-MANUEL" },
                magasin = pending.magasin
            )
            val result = repository.enregistrerVenteEtDecrementerStock(
                vente = vente,
                matchedArticleId = pending.matchedArticle?.id
            )
            _pendingTicket.value = null
            _snackbarMessage.value = if (result.articleUpdated) {
                "Ticket ${vente.numeroTicket} validé. Stock restant : ${result.remainingStock}."
            } else {
                "Ticket ${vente.numeroTicket} enregistré (${FormatUtils.formatFcfa(vente.montantTotalFcfa)})."
            }
            if (result.articleUpdated && result.remainingStock != null) {
                val prefs = _reminderPrefs.value
                if (prefs.lowStockAlertsEnabled && result.remainingStock <= prefs.lowStockThreshold) {
                    val lowItems = repository.findLowStockArticles(
                        threshold = prefs.lowStockThreshold,
                        magasin = vente.magasin
                    )
                    if (lowItems.isNotEmpty()) {
                        OrcaNotificationHelper.showLowStockNotification(
                            context = getApplication(),
                            lowStockArticles = lowItems,
                            threshold = prefs.lowStockThreshold,
                            magasinFilter = vente.magasin
                        )
                    }
                }
            }
        }
    }

    fun annulerValidationTicket() {
        _pendingTicket.value = null
    }

    fun supprimerVente(vente: VenteTicketEntity) {
        viewModelScope.launch {
            repository.deleteVente(vente)
            _snackbarMessage.value = "Ticket ${vente.numeroTicket} supprimé de l'historique."
        }
    }

    fun exporterRapportPdf(context: Context) {
        val filter = _rapportsFilter.value
        val ventes = filteredRapportsVentes.value
        val kpi = rapportKpi.value
        val periodeText = buildPeriodeLabel(filter)

        viewModelScope.launch {
            _isBusy.value = true
            try {
                val result = DocumentExporter.exporterRapportPdfA4(
                    context = context,
                    ventes = ventes,
                    periodeLabel = periodeText,
                    magasinFiltre = filter.magasin,
                    produitFiltre = filter.produitQuery,
                    kpi = kpi
                )
                repository.logExport(
                    ExportHistoryEntity(
                        typeExport = result.typeExport,
                        nomFichier = result.fileName,
                        cheminFichier = result.file.absolutePath,
                        nombreElements = result.nombreElements,
                        magasinFiltre = filter.magasin
                    )
                )
                DocumentExporter.shareFileWithFileProvider(context, result.file, result.mimeType)
                _snackbarMessage.value = "Rapport PDF A4 généré et prêt à partager."
            } catch (e: Exception) {
                _snackbarMessage.value = "Erreur génération PDF : ${e.localizedMessage}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun partagerRapportWhatsApp(context: Context) {
        val filter = _rapportsFilter.value
        val ventes = filteredRapportsVentes.value
        val kpi = rapportKpi.value
        val message = DocumentExporter.buildWhatsAppReportText(
            periodeLabel = buildPeriodeLabel(filter),
            magasinFiltre = filter.magasin,
            produitFiltre = filter.produitQuery,
            kpi = kpi,
            ventes = ventes
        )
        DocumentExporter.shareWhatsAppReport(context, message)
    }

    // --- RAPPELS & NOTIFICATIONS LOCALES (NotificationManager) ---

    private suspend fun triggerLowStockAlertIfNeeded(article: ArticleEntity) {
        val prefs = _reminderPrefs.value
        if (!prefs.lowStockAlertsEnabled || article.quantite > prefs.lowStockThreshold) return
        val lowItems = repository.findLowStockArticles(
            threshold = prefs.lowStockThreshold,
            magasin = article.magasin
        ).ifEmpty { listOf(article) }
        OrcaNotificationHelper.showLowStockNotification(
            context = getApplication(),
            lowStockArticles = lowItems,
            threshold = prefs.lowStockThreshold,
            magasinFilter = article.magasin
        )
    }

    fun updateLowStockAlertSettings(enabled: Boolean, threshold: Int) {
        val updated = _reminderPrefs.value.copy(
            lowStockAlertsEnabled = enabled,
            lowStockThreshold = threshold.coerceIn(0, 100)
        )
        _reminderPrefs.value = updated
        InventoryReminderScheduler.savePreferences(getApplication(), updated)
    }

    fun saveAndScheduleInventoryReminder(
        magasin: String,
        hour: Int,
        minute: Int,
        note: String
    ) {
        val updated = _reminderPrefs.value.copy(
            inventoryReminderEnabled = true,
            reminderMagasin = magasin,
            reminderHour = hour.coerceIn(0, 23),
            reminderMinute = minute.coerceIn(0, 59),
            reminderNote = note.trim()
        )
        _reminderPrefs.value = updated
        InventoryReminderScheduler.scheduleDailyInventoryReminder(getApplication(), updated)
        val hhmm = String.format(Locale.FRANCE, "%02d:%02d", updated.reminderHour, updated.reminderMinute)
        _snackbarMessage.value = "Rappel inventaire programmé à $hhmm (${updated.reminderMagasin})."
    }

    fun cancelInventoryReminder() {
        val current = _reminderPrefs.value
        InventoryReminderScheduler.cancelInventoryReminder(getApplication(), current)
        _reminderPrefs.value = current.copy(inventoryReminderEnabled = false)
        _snackbarMessage.value = "Rappel d'inventaire désactivé."
    }

    fun verifierEtNotifierStockBas(context: Context) {
        viewModelScope.launch {
            val prefs = _reminderPrefs.value
            val lowItems = repository.findLowStockArticles(
                threshold = prefs.lowStockThreshold,
                magasin = MagasinsOrca.TOUS_LES_SITES
            )
            if (lowItems.isEmpty()) {
                _snackbarMessage.value = "Aucun article sous le seuil de stock bas (≤ ${prefs.lowStockThreshold})."
            } else {
                val sent = OrcaNotificationHelper.showLowStockNotification(
                    context = context,
                    lowStockArticles = lowItems,
                    threshold = prefs.lowStockThreshold,
                    magasinFilter = MagasinsOrca.TOUS_LES_SITES
                )
                _snackbarMessage.value = if (sent) {
                    "Notification envoyée pour ${lowItems.size} article(s) en stock bas."
                } else {
                    "Activez l'autorisation de notifications pour afficher l'alerte."
                }
            }
        }
    }

    fun testerNotificationInventaire(
        context: Context,
        magasin: String,
        note: String
    ) {
        val sent = OrcaNotificationHelper.showScheduledInventoryNotification(
            context = context,
            magasin = magasin,
            note = note
        )
        _snackbarMessage.value = if (sent) {
            "Notification test de rappel d'inventaire envoyée."
        } else {
            "Activez l'autorisation de notifications pour tester le rappel."
        }
    }

    private fun buildPeriodeLabel(filter: RapportsFilterState): String {
        return if (filter.periode == PeriodeFiltre.DATE_PRECISE_LONGUE_DATE) {
            "Du ${FormatUtils.formatDate(filter.customStartMillis)} au ${FormatUtils.formatDate(filter.customEndMillis)}"
        } else {
            filter.periode.label
        }
    }

    private fun resolvePeriodBounds(filter: RapportsFilterState): Pair<Long, Long> {
        val now = System.currentTimeMillis()
        return when (filter.periode) {
            PeriodeFiltre.AUJOURD_HUI -> startOfDayMillis(now) to endOfDayMillis(now)
            PeriodeFiltre.CETTE_SEMAINE -> {
                val cal = Calendar.getInstance().apply {
                    firstDayOfWeek = Calendar.MONDAY
                    set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                cal.timeInMillis to endOfDayMillis(now)
            }
            PeriodeFiltre.CE_MOIS -> {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                cal.timeInMillis to endOfDayMillis(now)
            }
            PeriodeFiltre.TOUT_HISTORIQUE -> 0L to Long.MAX_VALUE
            PeriodeFiltre.DATE_PRECISE_LONGUE_DATE ->
                startOfDayMillis(filter.customStartMillis) to endOfDayMillis(filter.customEndMillis)
        }
    }

    companion object {
        fun startOfDayMillis(timeMillis: Long): Long {
            val cal = Calendar.getInstance().apply {
                this.timeInMillis = timeMillis
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        fun endOfDayMillis(timeMillis: Long): Long {
            val cal = Calendar.getInstance().apply {
                this.timeInMillis = timeMillis
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            }
            return cal.timeInMillis
        }

        fun defaultMultiYearStartMillis(): Long {
            val cal = Calendar.getInstance().apply {
                add(Calendar.YEAR, -2)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }
    }
}
