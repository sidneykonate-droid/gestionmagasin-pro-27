package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.db.MagasinDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InventoryReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val config = InventoryReminderScheduler.loadPreferences(context)
                if (config.inventoryReminderEnabled) {
                    OrcaNotificationHelper.showScheduledInventoryNotification(
                        context = context,
                        magasin = config.reminderMagasin,
                        note = config.reminderNote
                    )
                }

                if (config.lowStockAlertsEnabled) {
                    val lowStock = MagasinDatabase.getInstance(context)
                        .articleDao()
                        .findLowStockArticles(
                            threshold = config.lowStockThreshold,
                            magasin = config.reminderMagasin
                        )
                    if (lowStock.isNotEmpty()) {
                        OrcaNotificationHelper.showLowStockNotification(
                            context = context,
                            lowStockArticles = lowStock,
                            threshold = config.lowStockThreshold,
                            magasinFilter = config.reminderMagasin
                        )
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
