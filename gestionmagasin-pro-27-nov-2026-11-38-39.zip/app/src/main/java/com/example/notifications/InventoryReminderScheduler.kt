package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.data.model.MagasinsOrca
import java.util.Calendar

data class ReminderPreferences(
    val lowStockAlertsEnabled: Boolean = true,
    val lowStockThreshold: Int = 2,
    val inventoryReminderEnabled: Boolean = false,
    val reminderMagasin: String = MagasinsOrca.TOUS_LES_SITES,
    val reminderHour: Int = 9,
    val reminderMinute: Int = 0,
    val reminderNote: String = "Contrôle inventaire rayon & vérification des étiquettes"
)

object InventoryReminderScheduler {

    private const val PREFS_NAME = "orca_reminder_prefs"
    private const val KEY_LOW_STOCK_ENABLED = "low_stock_enabled"
    private const val KEY_LOW_STOCK_THRESHOLD = "low_stock_threshold"
    private const val KEY_INVENTORY_ENABLED = "inventory_enabled"
    private const val KEY_REMINDER_MAGASIN = "reminder_magasin"
    private const val KEY_REMINDER_HOUR = "reminder_hour"
    private const val KEY_REMINDER_MINUTE = "reminder_minute"
    private const val KEY_REMINDER_NOTE = "reminder_note"

    private const val REQUEST_CODE_DAILY_REMINDER = 4100

    fun loadPreferences(context: Context): ReminderPreferences {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return ReminderPreferences(
            lowStockAlertsEnabled = prefs.getBoolean(KEY_LOW_STOCK_ENABLED, true),
            lowStockThreshold = prefs.getInt(KEY_LOW_STOCK_THRESHOLD, 2),
            inventoryReminderEnabled = prefs.getBoolean(KEY_INVENTORY_ENABLED, false),
            reminderMagasin = prefs.getString(KEY_REMINDER_MAGASIN, MagasinsOrca.TOUS_LES_SITES)
                ?: MagasinsOrca.TOUS_LES_SITES,
            reminderHour = prefs.getInt(KEY_REMINDER_HOUR, 9),
            reminderMinute = prefs.getInt(KEY_REMINDER_MINUTE, 0),
            reminderNote = prefs.getString(
                KEY_REMINDER_NOTE,
                "Contrôle inventaire rayon & vérification des étiquettes"
            ).orEmpty()
        )
    }

    fun savePreferences(context: Context, config: ReminderPreferences) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_LOW_STOCK_ENABLED, config.lowStockAlertsEnabled)
            .putInt(KEY_LOW_STOCK_THRESHOLD, config.lowStockThreshold)
            .putBoolean(KEY_INVENTORY_ENABLED, config.inventoryReminderEnabled)
            .putString(KEY_REMINDER_MAGASIN, config.reminderMagasin)
            .putInt(KEY_REMINDER_HOUR, config.reminderHour)
            .putInt(KEY_REMINDER_MINUTE, config.reminderMinute)
            .putString(KEY_REMINDER_NOTE, config.reminderNote)
            .apply()
    }

    fun scheduleDailyInventoryReminder(context: Context, config: ReminderPreferences) {
        val updated = config.copy(inventoryReminderEnabled = true)
        savePreferences(context, updated)
        OrcaNotificationHelper.ensureChannels(context)

        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        val pendingIntent = buildReceiverPendingIntent(context)

        val triggerCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, updated.reminderHour.coerceIn(0, 23))
            set(Calendar.MINUTE, updated.reminderMinute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_MONTH, 1)
            }
        }

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            triggerCal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    fun cancelInventoryReminder(context: Context, currentConfig: ReminderPreferences) {
        savePreferences(context, currentConfig.copy(inventoryReminderEnabled = false))
        val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
        alarmManager.cancel(buildReceiverPendingIntent(context))
    }

    private fun buildReceiverPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, InventoryReminderReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_REMINDER,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
