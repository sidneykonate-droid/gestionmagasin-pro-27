package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.entity.ArticleEntity
import com.example.data.model.MagasinsOrca

object OrcaNotificationHelper {

    const val CHANNEL_LOW_STOCK = "orca_low_stock_channel"
    const val CHANNEL_INVENTORY_REMINDER = "orca_inventory_reminder_channel"

    private const val NOTIFICATION_ID_LOW_STOCK = 1001
    private const val NOTIFICATION_ID_INVENTORY = 1002

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun ensureChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val lowStockChannel = NotificationChannel(
            CHANNEL_LOW_STOCK,
            "Alertes Stock Bas ORCA DECO",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifications déclenchées lorsqu'un article atteint le seuil de stock bas."
            enableVibration(true)
        }

        val inventoryChannel = NotificationChannel(
            CHANNEL_INVENTORY_REMINDER,
            "Rappels Inventaire ORCA DECO",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Rappels locaux programmés pour les inventaires en magasin."
        }

        manager.createNotificationChannel(lowStockChannel)
        manager.createNotificationChannel(inventoryChannel)
    }

    fun showLowStockNotification(
        context: Context,
        lowStockArticles: List<ArticleEntity>,
        threshold: Int,
        magasinFilter: String = MagasinsOrca.TOUS_LES_SITES
    ): Boolean {
        if (!hasNotificationPermission(context) || lowStockArticles.isEmpty()) return false
        ensureChannels(context)

        val manager = context.getSystemService(NotificationManager::class.java) ?: return false
        val openAppIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_LOW_STOCK,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (lowStockArticles.size == 1) {
            val item = lowStockArticles.first()
            "Stock bas (${item.quantite} restant) • ${MagasinsOrca.shortLabel(item.magasin)}"
        } else {
            "Alerte Stock Bas : ${lowStockArticles.size} articles (≤ $threshold)"
        }

        val summaryLines = lowStockArticles.take(5).joinToString("\n") { art ->
            "• ${art.designation} (${art.reference}) : ${art.quantite} en stock — ${MagasinsOrca.shortLabel(art.magasin)}"
        }
        val extraLine = if (lowStockArticles.size > 5) {
            "\n+ ${lowStockArticles.size - 5} autre(s) article(s) sur $magasinFilter"
        } else ""

        val notification = NotificationCompat.Builder(context, CHANNEL_LOW_STOCK)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(
                lowStockArticles.firstOrNull()?.let {
                    "${it.designation} : ${it.quantite} unité(s) restante(s)"
                } ?: "Vérifiez le stock ORCA DECO"
            )
            .setStyle(NotificationCompat.BigTextStyle().bigText(summaryLines + extraLine))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        manager.notify(NOTIFICATION_ID_LOW_STOCK, notification)
        return true
    }

    fun showScheduledInventoryNotification(
        context: Context,
        magasin: String,
        note: String
    ): Boolean {
        if (!hasNotificationPermission(context)) return false
        ensureChannels(context)

        val manager = context.getSystemService(NotificationManager::class.java) ?: return false
        val openAppIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_INVENTORY,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val siteLabel = if (magasin == MagasinsOrca.TOUS_LES_SITES) {
            "Tous les sites ORCA DECO Abidjan"
        } else {
            "ORCA DECO $magasin"
        }
        val bodyText = note.ifBlank {
            "Pensez à effectuer le contrôle des stocks et à exporter le rapport du jour."
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_INVENTORY_REMINDER)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Inventaire programmé • $siteLabel")
            .setContentText(bodyText)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$siteLabel\n$bodyText"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        manager.notify(NOTIFICATION_ID_INVENTORY, notification)
        return true
    }
}
