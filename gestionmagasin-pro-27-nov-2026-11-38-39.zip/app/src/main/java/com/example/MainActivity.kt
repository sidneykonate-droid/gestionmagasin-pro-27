package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.automirrored.outlined.Label
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.notifications.OrcaNotificationHelper
import com.example.ui.screens.BaseArticlesScreen
import com.example.ui.screens.EtiquettesScreen
import com.example.ui.screens.OcrSaisieScreen
import com.example.ui.screens.OrcaBrandTopBar
import com.example.ui.screens.RappelsNotificationsDialog
import com.example.ui.screens.RapportsScreen
import com.example.ui.theme.GestionMagasinTheme
import com.example.viewmodel.MagasinViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OrcaNotificationHelper.ensureChannels(this)
        enableEdgeToEdge()
        setContent {
            GestionMagasinTheme {
                GestionMagasinProApp()
            }
        }
    }
}

private enum class MagasinTab(
    val titleRes: Int,
    val subtitle: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    OCR_SAISIE(
        titleRes = R.string.tab_ocr_saisie,
        subtitle = "Saisie & Scan ML Kit",
        selectedIcon = Icons.Filled.QrCodeScanner,
        unselectedIcon = Icons.Outlined.QrCodeScanner,
        testTag = "nav_tab_ocr"
    ),
    BASE(
        titleRes = R.string.tab_base,
        subtitle = "Base Articles & Stock",
        selectedIcon = Icons.Filled.Inventory2,
        unselectedIcon = Icons.Outlined.Inventory2,
        testTag = "nav_tab_base"
    ),
    ETIQUETTES(
        titleRes = R.string.tab_etiquettes,
        subtitle = "Planches Word & Excel",
        selectedIcon = Icons.AutoMirrored.Filled.Label,
        unselectedIcon = Icons.AutoMirrored.Outlined.Label,
        testTag = "nav_tab_etiquettes"
    ),
    RAPPORTS(
        titleRes = R.string.tab_rapports,
        subtitle = "Tickets, KPI & PDF",
        selectedIcon = Icons.Filled.Assessment,
        unselectedIcon = Icons.Outlined.Assessment,
        testTag = "nav_tab_rapports"
    )
}

@Composable
fun GestionMagasinProApp(
    viewModel: MagasinViewModel = viewModel()
) {
    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tabs = MagasinTab.entries
    val currentTab = tabs[selectedTabIndex]

    val ocrFormState by viewModel.ocrFormState.collectAsStateWithLifecycle()
    val baseSearchQuery by viewModel.baseSearchQuery.collectAsStateWithLifecycle()
    val baseMagasinFilter by viewModel.baseMagasinFilter.collectAsStateWithLifecycle()
    val filteredBaseArticles by viewModel.filteredBaseArticles.collectAsStateWithLifecycle()

    val etiquettesMagasinFilter by viewModel.etiquettesMagasinFilter.collectAsStateWithLifecycle()
    val etiquettesSelectedIds by viewModel.etiquettesSelectedIds.collectAsStateWithLifecycle()
    val filteredEtiquettesArticles by viewModel.filteredEtiquettesArticles.collectAsStateWithLifecycle()
    val allExports by viewModel.allExports.collectAsStateWithLifecycle()

    val allArticles by viewModel.allArticles.collectAsStateWithLifecycle()
    val rapportsFilter by viewModel.rapportsFilter.collectAsStateWithLifecycle()
    val filteredRapportsVentes by viewModel.filteredRapportsVentes.collectAsStateWithLifecycle()
    val rapportKpi by viewModel.rapportKpi.collectAsStateWithLifecycle()
    val monthlySalesPoints by viewModel.monthlySalesPoints.collectAsStateWithLifecycle()
    val pendingTicket by viewModel.pendingTicket.collectAsStateWithLifecycle()

    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val reminderPrefs by viewModel.reminderPrefs.collectAsStateWithLifecycle()
    val lowStockArticles by viewModel.lowStockArticles.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var showNotificationsDialog by rememberSaveable { mutableStateOf(false) }

    if (showNotificationsDialog) {
        RappelsNotificationsDialog(
            prefs = reminderPrefs,
            lowStockArticles = lowStockArticles,
            onDismiss = { showNotificationsDialog = false },
            onUpdateLowStockSettings = { enabled, threshold ->
                viewModel.updateLowStockAlertSettings(enabled, threshold)
            },
            onScheduleInventoryReminder = { magasin, hour, minute, note ->
                viewModel.saveAndScheduleInventoryReminder(magasin, hour, minute, note)
            },
            onCancelInventoryReminder = { viewModel.cancelInventoryReminder() },
            onCheckLowStockNow = { viewModel.verifierEtNotifierStockBas(context) },
            onTestInventoryNotification = { magasin, note ->
                viewModel.testerNotificationInventaire(context, magasin, note)
            }
        )
    }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbarMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            OrcaBrandTopBar(
                subtitle = currentTab.subtitle,
                isBusy = isBusy,
                lowStockCount = lowStockArticles.size,
                reminderActive = reminderPrefs.inventoryReminderEnabled,
                onOpenNotifications = { showNotificationsDialog = true }
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, tab ->
                    val selected = selectedTabIndex == index
                    val label = stringResource(tab.titleRes)
                    NavigationBarItem(
                        selected = selected,
                        onClick = { selectedTabIndex = index },
                        icon = {
                            Icon(
                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = label
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MagasinTab.OCR_SAISIE -> OcrSaisieScreen(
                    formState = ocrFormState,
                    viewModel = viewModel
                )
                MagasinTab.BASE -> BaseArticlesScreen(
                    articles = filteredBaseArticles,
                    searchQuery = baseSearchQuery,
                    selectedMagasin = baseMagasinFilter,
                    viewModel = viewModel,
                    onEditInFormTab = { selectedTabIndex = 0 }
                )
                MagasinTab.ETIQUETTES -> EtiquettesScreen(
                    articles = filteredEtiquettesArticles,
                    selectedMagasin = etiquettesMagasinFilter,
                    selectedIds = etiquettesSelectedIds,
                    exportHistory = allExports,
                    isBusy = isBusy,
                    viewModel = viewModel
                )
                MagasinTab.RAPPORTS -> RapportsScreen(
                    ventes = filteredRapportsVentes,
                    allArticles = allArticles,
                    filterState = rapportsFilter,
                    kpi = rapportKpi,
                    monthlyPoints = monthlySalesPoints,
                    pendingTicket = pendingTicket,
                    isBusy = isBusy,
                    viewModel = viewModel
                )
            }
        }
    }
}
