package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.entity.ArticleEntity
import com.example.data.entity.VenteTicketEntity
import com.example.data.model.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.xssf.usermodel.XSSFColor
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.xwpf.usermodel.ParagraphAlignment
import org.apache.poi.xwpf.usermodel.TableRowAlign
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFTable
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STHeightRule
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger

data class ExportResult(
    val file: File,
    val fileName: String,
    val mimeType: String,
    val typeExport: String,
    val nombreElements: Int
)

data class RapportKpiSummary(
    val quantiteTotaleVendue: Int,
    val chiffreAffairesFcfa: Long,
    val valorisationStockFcfa: Long,
    val nombreTickets: Int
)

object DocumentExporter {

    const val MIME_DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    const val MIME_PDF = "application/pdf"

    private fun configurePoiXmlProperties() {
        System.setProperty(
            "org.apache.poi.javax.xml.stream.XMLInputFactory",
            "com.fasterxml.aalto.stax.InputFactoryImpl"
        )
        System.setProperty(
            "org.apache.poi.javax.xml.stream.XMLOutputFactory",
            "com.fasterxml.aalto.stax.OutputFactoryImpl"
        )
        System.setProperty(
            "org.apache.poi.javax.xml.stream.XMLEventFactory",
            "com.fasterxml.aalto.stax.EventFactoryImpl"
        )
        System.setProperty(
            "javax.xml.stream.XMLInputFactory",
            "com.fasterxml.aalto.stax.InputFactoryImpl"
        )
        System.setProperty(
            "javax.xml.stream.XMLOutputFactory",
            "com.fasterxml.aalto.stax.OutputFactoryImpl"
        )
        System.setProperty(
            "javax.xml.stream.XMLEventFactory",
            "com.fasterxml.aalto.stax.EventFactoryImpl"
        )
    }

    private fun getExportsDir(context: Context): File {
        val dir = File(context.filesDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Génère une planche d'étiquettes Word (.docx) au format RVOITURE
     * en grille 2 colonnes x 5 lignes par page A4.
     */
    suspend fun exporterPlancheEtiquettesDocx(
        context: Context,
        articles: List<ArticleEntity>,
        magasinFiltre: String
    ): ExportResult = withContext(Dispatchers.IO) {
        configurePoiXmlProperties()

        val document = XWPFDocument()
        val body = document.document.body
        val sectPr = if (body.isSetSectPr) body.sectPr else body.addNewSectPr()
        val pgSz = if (sectPr.isSetPgSz) sectPr.pgSz else sectPr.addNewPgSz()
        // Format A4 en twips (210mm x 297mm)
        pgSz.w = BigInteger.valueOf(11906)
        pgSz.h = BigInteger.valueOf(16838)

        val pgMar = if (sectPr.isSetPgMar) sectPr.pgMar else sectPr.addNewPgMar()
        pgMar.top = BigInteger.valueOf(567)
        pgMar.bottom = BigInteger.valueOf(567)
        pgMar.left = BigInteger.valueOf(567)
        pgMar.right = BigInteger.valueOf(567)

        val headerParagraph = document.createParagraph().apply {
            alignment = ParagraphAlignment.CENTER
            spacingAfter = 120
        }
        headerParagraph.createRun().apply {
            isBold = true
            fontSize = 11
            color = "B44B27"
            setText("ORCA DECO ABIDJAN — PLANCHE ÉTIQUETTES RVOITURE (2×5) • $magasinFiltre")
        }

        // Découpage par pages de 10 étiquettes (2 colonnes x 5 lignes)
        val pages = if (articles.isEmpty()) listOf(emptyList()) else articles.chunked(10)

        pages.forEachIndexed { pageIndex, pageItems ->
            if (pageIndex > 0) {
                document.createParagraph().apply {
                    isPageBreak = true
                }
            }

            val table: XWPFTable = document.createTable(5, 2)
            table.setTableAlignment(TableRowAlign.CENTER)
            val tblPr = table.ctTbl.tblPr ?: table.ctTbl.addNewTblPr()

            val borders = tblPr.tblBorders ?: tblPr.addNewTblBorders()
            listOf(
                borders.addNewTop(),
                borders.addNewBottom(),
                borders.addNewLeft(),
                borders.addNewRight(),
                borders.addNewInsideH(),
                borders.addNewInsideV()
            ).forEach { border ->
                border.`val` = STBorder.SINGLE
                border.sz = BigInteger.valueOf(8)
                border.color = "C8BEB4"
            }

            for (rowIndex in 0 until 5) {
                val row = table.getRow(rowIndex)
                val trPr = row.ctRow.trPr ?: row.ctRow.addNewTrPr()
                val trHeight = trPr.addNewTrHeight()
                trHeight.`val` = BigInteger.valueOf(2800) // ~4.9 cm par ligne pour tenir 5 lignes sur A4
                trHeight.hRule = STHeightRule.EXACT

                for (colIndex in 0 until 2) {
                    val cell = row.getCell(colIndex)
                    val tcPr = cell.ctTc.tcPr ?: cell.ctTc.addNewTcPr()
                    val tcW = tcPr.tcW ?: tcPr.addNewTcW()
                    tcW.w = BigInteger.valueOf(5380)

                    val itemIndex = rowIndex * 2 + colIndex
                    val article = pageItems.getOrNull(itemIndex)

                    // Nettoyer le paragraphe par défaut
                    val pTop = cell.paragraphs.firstOrNull() ?: cell.addParagraph()
                    pTop.alignment = ParagraphAlignment.LEFT
                    pTop.spacingBefore = 60
                    pTop.spacingAfter = 40

                    if (article != null) {
                        pTop.createRun().apply {
                            isBold = true
                            fontSize = 8
                            color = "B44B27"
                            setText("ORCA DECO • ${article.magasin.uppercase()}")
                        }

                        val pDesig = cell.addParagraph().apply {
                            spacingAfter = 60
                        }
                        pDesig.createRun().apply {
                            isBold = true
                            fontSize = 11
                            color = "2B2927"
                            setText(article.designation.take(64))
                        }

                        val pRef = cell.addParagraph().apply {
                            spacingAfter = 80
                        }
                        pRef.createRun().apply {
                            fontFamily = "Courier New"
                            fontSize = 9
                            color = "5F5852"
                            setText("Réf: ${article.reference.ifBlank { "-" }}  |  CB: ${article.codeBarre}")
                        }

                        val pPrice = cell.addParagraph().apply {
                            alignment = ParagraphAlignment.RIGHT
                            spacingBefore = 40
                        }
                        pPrice.createRun().apply {
                            isBold = true
                            fontSize = 15
                            color = "B44B27"
                            setText(FormatUtils.formatFcfa(article.prixFcfa))
                        }
                    } else {
                        pTop.createRun().apply {
                            fontSize = 8
                            color = "BDB4AB"
                            setText("Emplacement libre — ORCA DECO")
                        }
                    }
                }
            }
        }

        val fileName = "ORCA_Etiquettes_RVOITURE_${FormatUtils.formatFileTimestamp()}.docx"
        val outFile = File(getExportsDir(context), fileName)
        FileOutputStream(outFile).use { fos ->
            document.write(fos)
        }
        document.close()

        ExportResult(
            file = outFile,
            fileName = fileName,
            mimeType = MIME_DOCX,
            typeExport = "DOCX",
            nombreElements = articles.size
        )
    }

    /**
     * Génère un classeur Excel (.xlsx) complet des articles sélectionnés.
     */
    suspend fun exporterClasseurExcelXlsx(
        context: Context,
        articles: List<ArticleEntity>,
        magasinFiltre: String
    ): ExportResult = withContext(Dispatchers.IO) {
        configurePoiXmlProperties()

        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Articles ORCA DECO")

        val headerFont = workbook.createFont().apply {
            bold = true
            color = IndexedColors.WHITE.index
            fontHeightInPoints = 11
        }
        val headerStyle = workbook.createCellStyle().apply {
            setFillForegroundColor(XSSFColor(byteArrayOf(180.toByte(), 75.toByte(), 39.toByte()), null))
            fillPattern = FillPatternType.SOLID_FOREGROUND
            setFont(headerFont)
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
            borderBottom = BorderStyle.THIN
            borderTop = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }

        val cellStyle = workbook.createCellStyle().apply {
            verticalAlignment = VerticalAlignment.CENTER
            borderBottom = BorderStyle.THIN
            borderTop = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }

        val numberStyle = workbook.createCellStyle().apply {
            cloneStyleFrom(cellStyle)
            alignment = HorizontalAlignment.RIGHT
            dataFormat = workbook.createDataFormat().getFormat("#,##0")
        }

        val titleRow = sheet.createRow(0)
        titleRow.createCell(0).setCellValue("ORCA DECO ABIDJAN — Inventaire & Tarifs ($magasinFiltre)")

        val headers = listOf(
            "Code-barres",
            "Référence",
            "Désignation",
            "Prix (FCFA)",
            "Quantité",
            "Valeur Stock (FCFA)",
            "Magasin",
            "Dernière MAJ"
        )

        val headerRow = sheet.createRow(2).apply { heightInPoints = 24f }
        headers.forEachIndexed { colIndex, title ->
            headerRow.createCell(colIndex).apply {
                setCellValue(title)
                setCellStyle(headerStyle)
            }
        }

        var totalStockValue = 0L
        var totalUnits = 0

        articles.forEachIndexed { idx, article ->
            val row = sheet.createRow(idx + 3)
            val lineValue = article.prixFcfa * article.quantite
            totalStockValue += lineValue
            totalUnits += article.quantite

            row.createCell(0).apply { setCellValue(article.codeBarre); setCellStyle(cellStyle) }
            row.createCell(1).apply { setCellValue(article.reference); setCellStyle(cellStyle) }
            row.createCell(2).apply { setCellValue(article.designation); setCellStyle(cellStyle) }
            row.createCell(3).apply { setCellValue(article.prixFcfa.toDouble()); setCellStyle(numberStyle) }
            row.createCell(4).apply { setCellValue(article.quantite.toDouble()); setCellStyle(numberStyle) }
            row.createCell(5).apply { setCellValue(lineValue.toDouble()); setCellStyle(numberStyle) }
            row.createCell(6).apply { setCellValue(article.magasin); setCellStyle(cellStyle) }
            row.createCell(7).apply { setCellValue(FormatUtils.formatDateTime(article.dateMaj)); setCellStyle(cellStyle) }
        }

        val totalRow = sheet.createRow(articles.size + 4)
        totalRow.createCell(2).apply { setCellValue("TOTAL GÉNÉRAL"); setCellStyle(headerStyle) }
        totalRow.createCell(4).apply { setCellValue(totalUnits.toDouble()); setCellStyle(numberStyle) }
        totalRow.createCell(5).apply { setCellValue(totalStockValue.toDouble()); setCellStyle(numberStyle) }

        // Largeurs explicites (évite java.awt sur Android)
        val columnWidths = listOf(18, 16, 36, 16, 12, 20, 28, 20)
        columnWidths.forEachIndexed { col, widthChars ->
            sheet.setColumnWidth(col, widthChars * 256)
        }

        val fileName = "ORCA_Base_Articles_${FormatUtils.formatFileTimestamp()}.xlsx"
        val outFile = File(getExportsDir(context), fileName)
        FileOutputStream(outFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()

        ExportResult(
            file = outFile,
            fileName = fileName,
            mimeType = MIME_XLSX,
            typeExport = "XLSX",
            nombreElements = articles.size
        )
    }

    /**
     * Génère un rapport PDF A4 complet des ventes tickets et de la valorisation du stock.
     */
    suspend fun exporterRapportPdfA4(
        context: Context,
        ventes: List<VenteTicketEntity>,
        periodeLabel: String,
        magasinFiltre: String,
        produitFiltre: String,
        kpi: RapportKpiSummary
    ): ExportResult = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 36f

        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(255, 224, 212)
            textSize = 10f
        }
        val headerBgPaint = Paint().apply {
            color = Color.rgb(180, 75, 39)
        }
        val kpiBoxPaint = Paint().apply {
            color = Color.rgb(245, 239, 234)
        }
        val labelPaint = Paint().apply {
            color = Color.rgb(95, 88, 82)
            textSize = 9f
        }
        val valuePaint = Paint().apply {
            color = Color.rgb(43, 41, 39)
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(43, 41, 39)
        }
        val tableHeaderText = Paint().apply {
            color = Color.WHITE
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val rowTextPaint = Paint().apply {
            color = Color.rgb(31, 28, 26)
            textSize = 8.5f
        }
        val dividerPaint = Paint().apply {
            color = Color.rgb(220, 212, 204)
            strokeWidth = 0.8f
        }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas: Canvas = page.canvas

        fun drawHeaderAndKpis(c: Canvas, isFirstPage: Boolean): Float {
            c.drawRect(0f, 0f, pageWidth.toFloat(), 76f, headerBgPaint)
            c.drawText("ORCA DECO ABIDJAN — RAPPORT D'ACTIVITÉ", margin, 32f, titlePaint)
            c.drawText(
                "Site : $magasinFiltre  |  Période : $periodeLabel  |  Généré le ${FormatUtils.formatDateTime(System.currentTimeMillis())}",
                margin,
                54f,
                subtitlePaint
            )

            var y = 94f
            if (isFirstPage) {
                if (produitFiltre.isNotBlank()) {
                    c.drawText("Filtre article : $produitFiltre", margin, y, valuePaint.apply { textSize = 10f })
                    y += 18f
                }

                val boxWidth = (pageWidth - margin * 2 - 16f) / 3f
                val boxHeight = 52f

                // KPI 1
                c.drawRoundRect(margin, y, margin + boxWidth, y + boxHeight, 8f, 8f, kpiBoxPaint)
                c.drawText("QUANTITÉ VENDUE", margin + 10f, y + 18f, labelPaint)
                c.drawText("${kpi.quantiteTotaleVendue} unités (${kpi.nombreTickets} tickets)", margin + 10f, y + 38f, valuePaint.apply { textSize = 11f })

                // KPI 2
                val x2 = margin + boxWidth + 8f
                c.drawRoundRect(x2, y, x2 + boxWidth, y + boxHeight, 8f, 8f, kpiBoxPaint)
                c.drawText("CA TICKETS", x2 + 10f, y + 18f, labelPaint)
                c.drawText(FormatUtils.formatFcfa(kpi.chiffreAffairesFcfa), x2 + 10f, y + 38f, valuePaint)

                // KPI 3
                val x3 = x2 + boxWidth + 8f
                c.drawRoundRect(x3, y, x3 + boxWidth, y + boxHeight, 8f, 8f, kpiBoxPaint)
                c.drawText("VALORISATION STOCK", x3 + 10f, y + 18f, labelPaint)
                c.drawText(FormatUtils.formatFcfa(kpi.valorisationStockFcfa), x3 + 10f, y + 38f, valuePaint)

                y += boxHeight + 18f
            }

            // En-tête tableau
            c.drawRect(margin, y, pageWidth - margin, y + 22f, tableHeaderPaint)
            c.drawText("Date", margin + 6f, y + 14f, tableHeaderText)
            c.drawText("Ticket", margin + 68f, y + 14f, tableHeaderText)
            c.drawText("Désignation / Code", margin + 132f, y + 14f, tableHeaderText)
            c.drawText("Site", margin + 328f, y + 14f, tableHeaderText)
            c.drawText("Qté", margin + 432f, y + 14f, tableHeaderText)
            c.drawText("Montant", margin + 468f, y + 14f, tableHeaderText)

            return y + 30f
        }

        var currentY = drawHeaderAndKpis(canvas, true)

        if (ventes.isEmpty()) {
            canvas.drawText(
                "Aucune vente enregistrée pour les critères sélectionnés.",
                margin,
                currentY + 12f,
                rowTextPaint
            )
        } else {
            ventes.forEach { vente ->
                if (currentY > pageHeight - 54f) {
                    canvas.drawText(
                        "Page $pageNumber — GestionMagasin Pro ORCA DECO",
                        margin,
                        pageHeight - 22f,
                        labelPaint
                    )
                    pdfDocument.finishPage(page)
                    pageNumber += 1
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = drawHeaderAndKpis(canvas, false)
                }

                canvas.drawText(FormatUtils.formatDate(vente.dateVenteTimestamp), margin + 6f, currentY, rowTextPaint)
                canvas.drawText(vente.numeroTicket.take(12), margin + 68f, currentY, rowTextPaint)
                val productLabel = "${vente.designation.take(26)} (${vente.codeBarre.takeLast(6)})"
                canvas.drawText(productLabel, margin + 132f, currentY, rowTextPaint)
                canvas.drawText(vente.magasin.take(16), margin + 328f, currentY, rowTextPaint)
                canvas.drawText("${vente.quantiteVendue}", margin + 435f, currentY, rowTextPaint)
                canvas.drawText(FormatUtils.formatFcfa(vente.montantTotalFcfa), margin + 468f, currentY, rowTextPaint)

                canvas.drawLine(margin, currentY + 6f, pageWidth - margin, currentY + 6f, dividerPaint)
                currentY += 20f
            }
        }

        canvas.drawText(
            "Page $pageNumber — GestionMagasin Pro ORCA DECO",
            margin,
            pageHeight - 22f,
            labelPaint
        )
        pdfDocument.finishPage(page)

        val fileName = "ORCA_Rapport_Ventes_${FormatUtils.formatFileTimestamp()}.pdf"
        val outFile = File(getExportsDir(context), fileName)
        FileOutputStream(outFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()

        ExportResult(
            file = outFile,
            fileName = fileName,
            mimeType = MIME_PDF,
            typeExport = "PDF",
            nombreElements = ventes.size
        )
    }

    fun shareFileWithFileProvider(context: Context, file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(
            shareIntent,
            context.getString(R.string.share_file_chooser)
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun buildWhatsAppReportText(
        periodeLabel: String,
        magasinFiltre: String,
        produitFiltre: String,
        kpi: RapportKpiSummary,
        ventes: List<VenteTicketEntity>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("*ORCA DECO ABIDJAN — RAPPORT VENTES & STOCK*")
        sb.appendLine("Site : $magasinFiltre")
        sb.appendLine("Période : $periodeLabel")
        if (produitFiltre.isNotBlank()) {
            sb.appendLine("Article filtré : $produitFiltre")
        }
        sb.appendLine("-----------------------------")
        sb.appendLine("• Tickets validés : ${kpi.nombreTickets}")
        sb.appendLine("• Quantité vendue : ${kpi.quantiteTotaleVendue} unité(s)")
        sb.appendLine("• Chiffre d'affaires : *${FormatUtils.formatFcfa(kpi.chiffreAffairesFcfa)}*")
        sb.appendLine("• Valorisation stock : ${FormatUtils.formatFcfa(kpi.valorisationStockFcfa)}")

        if (ventes.isNotEmpty()) {
            sb.appendLine("-----------------------------")
            sb.appendLine("*Détail récent (${minOf(ventes.size, 15)} sur ${ventes.size}) :*")
            ventes.take(15).forEach { v ->
                sb.appendLine(
                    "- ${FormatUtils.formatDate(v.dateVenteTimestamp)} | ${v.numeroTicket} | ${v.designation} x${v.quantiteVendue} → ${FormatUtils.formatFcfa(v.montantTotalFcfa)}"
                )
            }
        }
        return sb.toString()
    }

    fun shareWhatsAppReport(context: Context, message: String) {
        val pm = context.packageManager
        val whatsappPackage = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
            try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            if (whatsappPackage != null) {
                setPackage(whatsappPackage)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            if (whatsappPackage != null) {
                context.startActivity(intent)
            } else {
                val chooser = Intent.createChooser(
                    intent,
                    context.getString(R.string.share_whatsapp_chooser)
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(chooser)
            }
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
            }
            val chooser = Intent.createChooser(
                fallback,
                context.getString(R.string.share_whatsapp_chooser)
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(chooser)
        }
    }
}
