package com.example.data.model

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MagasinsOrca {
    const val TOUS_LES_SITES = "Tous les sites"
    const val MARCORY = "Marcory"
    const val RIVIERA = "Riviera Palmeraie Abidjan Mall"
    const val YOPOUGON = "Yopougon Kouté"

    val SITES: List<String> = listOf(MARCORY, RIVIERA, YOPOUGON)

    fun shortLabel(site: String): String = when (site) {
        RIVIERA -> "Riviera Mall"
        YOPOUGON -> "Yopougon Kouté"
        else -> site
    }
}

object FormatUtils {
    private val fcfaSymbols = DecimalFormatSymbols(Locale.FRANCE).apply {
        groupingSeparator = ' '
    }
    private val fcfaFormatter = DecimalFormat("#,##0", fcfaSymbols)

    fun formatFcfa(amount: Long): String {
        return "${fcfaFormatter.format(amount)} FCFA"
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
        return sdf.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        return sdf.format(Date(timestamp))
    }

    fun formatFileTimestamp(timestamp: Long = System.currentTimeMillis()): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        return sdf.format(Date(timestamp))
    }
}
