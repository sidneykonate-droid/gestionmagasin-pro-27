package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.ArticleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ArticleDao {

    @Query("SELECT * FROM articles ORDER BY dateMaj DESC, id DESC")
    fun observeAllArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE codeBarre = :codeBarre LIMIT 1")
    suspend fun findByCodeBarre(codeBarre: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE codeBarre = :codeBarre AND magasin = :magasin LIMIT 1")
    suspend fun findByCodeBarreAndMagasin(codeBarre: String, magasin: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    suspend fun findById(id: Long): ArticleEntity?

    @Query(
        """
        SELECT * FROM articles
        WHERE quantite <= :threshold
          AND (:magasin = 'Tous les sites' OR magasin = :magasin)
        ORDER BY quantite ASC, designation ASC
        """
    )
    suspend fun findLowStockArticles(threshold: Int, magasin: String): List<ArticleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticle(article: ArticleEntity): Long

    @Update
    suspend fun updateArticle(article: ArticleEntity)

    @Delete
    suspend fun deleteArticle(article: ArticleEntity)

    @Query("DELETE FROM articles WHERE id = :id")
    suspend fun deleteById(id: Long)
}
