package com.example.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ventes_tickets",
    indices = [
        Index(value = ["codeBarre"]),
        Index(value = ["dateVenteTimestamp"]),
        Index(value = ["magasin"])
    ]
)
data class VenteTicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val codeBarre: String,
    val reference: String,
    val designation: String,
    val quantiteVendue: Int,
    val prixUnitaireFcfa: Long,
    val montantTotalFcfa: Long,
    val dateVenteTimestamp: Long,
    val numeroTicket: String,
    val magasin: String
)
