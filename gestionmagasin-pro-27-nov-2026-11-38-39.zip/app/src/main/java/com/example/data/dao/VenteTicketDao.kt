package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.VenteTicketEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VenteTicketDao {

    @Query("SELECT * FROM ventes_tickets ORDER BY dateVenteTimestamp DESC, id DESC")
    fun observeAllVentes(): Flow<List<VenteTicketEntity>>

    @Query(
        """
        SELECT * FROM ventes_tickets
        WHERE (:magasin = 'Tous les sites' OR magasin = :magasin)
          AND dateVenteTimestamp BETWEEN :startMillis AND :endMillis
        ORDER BY dateVenteTimestamp DESC, id DESC
        """
    )
    fun observeVentesFiltered(
        magasin: String,
        startMillis: Long,
        endMillis: Long
    ): Flow<List<VenteTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVente(vente: VenteTicketEntity): Long

    @Delete
    suspend fun deleteVente(vente: VenteTicketEntity)
}
