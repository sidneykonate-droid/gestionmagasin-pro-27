package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.ArticleDao
import com.example.data.dao.ExportHistoryDao
import com.example.data.dao.VenteTicketDao
import com.example.data.entity.ArticleEntity
import com.example.data.entity.ExportHistoryEntity
import com.example.data.entity.VenteTicketEntity

@Database(
    entities = [
        ArticleEntity::class,
        VenteTicketEntity::class,
        ExportHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MagasinDatabase : RoomDatabase() {

    abstract fun articleDao(): ArticleDao
    abstract fun venteTicketDao(): VenteTicketDao
    abstract fun exportHistoryDao(): ExportHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: MagasinDatabase? = null

        fun getInstance(context: Context): MagasinDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MagasinDatabase::class.java,
                    "gestion_magasin_orca_deco.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
