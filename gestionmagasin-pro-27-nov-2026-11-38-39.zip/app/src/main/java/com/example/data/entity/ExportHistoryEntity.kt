package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "export_history")
data class ExportHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val typeExport: String, // "DOCX", "XLSX", "PDF"
    val nomFichier: String,
    val cheminFichier: String,
    val nombreElements: Int,
    val magasinFiltre: String,
    val dateExport: Long = System.currentTimeMillis()
)
