package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.db.MagasinDatabase
import com.example.data.entity.ArticleEntity
import com.example.data.entity.ExportHistoryEntity
import com.example.data.entity.VenteTicketEntity
import kotlinx.coroutines.flow.Flow

class MagasinRepository(private val database: MagasinDatabase) {

    private val articleDao = database.articleDao()
    private val venteTicketDao = database.venteTicketDao()
    private val exportHistoryDao = database.exportHistoryDao()

    val allArticles: Flow<List<ArticleEntity>> = articleDao.observeAllArticles()
    val allVentes: Flow<List<VenteTicketEntity>> = venteTicketDao.observeAllVentes()
    val allExports: Flow<List<ExportHistoryEntity>> = exportHistoryDao.observeAllExports()

    suspend fun findArticleByCodeBarre(codeBarre: String): ArticleEntity? {
        val cleaned = codeBarre.trim()
        if (cleaned.isEmpty()) return null
        return articleDao.findByCodeBarre(cleaned)
    }

    suspend fun findArticleByCodeBarreAndMagasin(codeBarre: String, magasin: String): ArticleEntity? {
        val cleaned = codeBarre.trim()
        if (cleaned.isEmpty()) return null
        return articleDao.findByCodeBarreAndMagasin(cleaned, magasin)
            ?: articleDao.findByCodeBarre(cleaned)
    }

    suspend fun findLowStockArticles(threshold: Int, magasin: String): List<ArticleEntity> {
        return articleDao.findLowStockArticles(threshold, magasin)
    }

    suspend fun saveArticle(article: ArticleEntity): Long {
        return if (article.id > 0L) {
            articleDao.updateArticle(article.copy(dateMaj = System.currentTimeMillis()))
            article.id
        } else {
            articleDao.insertArticle(article.copy(dateMaj = System.currentTimeMillis()))
        }
    }

    suspend fun deleteArticle(article: ArticleEntity) {
        articleDao.deleteArticle(article)
    }

    /**
     * Enregistre une vente de ticket de caisse et décrémente automatiquement
     * la quantité en stock de l'article correspondant dans une transaction atomique.
     */
    suspend fun enregistrerVenteEtDecrementerStock(
        vente: VenteTicketEntity,
        matchedArticleId: Long?
    ): StockUpdateResult {
        return database.withTransaction {
            venteTicketDao.insertVente(vente)

            val targetArticle = when {
                matchedArticleId != null && matchedArticleId > 0L ->
                    articleDao.findById(matchedArticleId)
                vente.codeBarre.isNotBlank() ->
                    articleDao.findByCodeBarreAndMagasin(vente.codeBarre.trim(), vente.magasin)
                else -> null
            }

            if (targetArticle != null) {
                val nouveauStock = (targetArticle.quantite - vente.quantiteVendue).coerceAtLeast(0)
                articleDao.updateArticle(
                    targetArticle.copy(
                        quantite = nouveauStock,
                        dateMaj = System.currentTimeMillis()
                    )
                )
                StockUpdateResult(
                    articleUpdated = true,
                    articleDesignation = targetArticle.designation,
                    remainingStock = nouveauStock
                )
            } else {
                StockUpdateResult(
                    articleUpdated = false,
                    articleDesignation = vente.designation,
                    remainingStock = null
                )
            }
        }
    }

    suspend fun deleteVente(vente: VenteTicketEntity) {
        venteTicketDao.deleteVente(vente)
    }

    suspend fun logExport(exportHistory: ExportHistoryEntity): Long {
        return exportHistoryDao.insertExport(exportHistory)
    }
}

data class StockUpdateResult(
    val articleUpdated: Boolean,
    val articleDesignation: String,
    val remainingStock: Int?
)
