package com.example.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "articles",
    indices = [
        Index(value = ["codeBarre"]),
        Index(value = ["reference"]),
        Index(value = ["magasin"])
    ]
)
data class ArticleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val codeBarre: String,
    val reference: String,
    val designation: String,
    val prixFcfa: Long,
    val quantite: Int,
    val magasin: String,
    val dateMaj: Long = System.currentTimeMillis()
)
