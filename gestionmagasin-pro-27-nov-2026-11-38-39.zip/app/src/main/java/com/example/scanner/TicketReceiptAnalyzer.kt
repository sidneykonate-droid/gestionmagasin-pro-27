package com.example.scanner

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ProductOcrResult(
    val codeBarre: String = "",
    val reference: String = "",
    val designation: String = "",
    val prixFcfa: Long? = null,
    val rawText: String = ""
)

data class TicketReceiptResult(
    val codeBarre: String = "",
    val numeroTicket: String = "",
    val dateVenteTimestamp: Long = System.currentTimeMillis(),
    val dateDetecteeTexte: String = "",
    val montantTotalFcfa: Long? = null,
    val quantiteDetectee: Int = 1,
    val rawText: String = ""
)

object TicketReceiptAnalyzer {

    private val barcodeOptions = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(
            Barcode.FORMAT_EAN_13,
            Barcode.FORMAT_EAN_8,
            Barcode.FORMAT_UPC_A,
            Barcode.FORMAT_UPC_E,
            Barcode.FORMAT_CODE_128,
            Barcode.FORMAT_CODE_39,
            Barcode.FORMAT_CODE_93,
            Barcode.FORMAT_ITF,
            Barcode.FORMAT_QR_CODE
        )
        .build()

    suspend fun analyzeProductBitmap(bitmap: Bitmap): ProductOcrResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        return analyzeProductImage(image)
    }

    suspend fun analyzeProductUri(context: Context, uri: Uri): ProductOcrResult {
        val image = InputImage.fromFilePath(context, uri)
        return analyzeProductImage(image)
    }

    suspend fun analyzeTicketBitmap(bitmap: Bitmap): TicketReceiptResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        return analyzeTicketImage(image)
    }

    suspend fun analyzeTicketUri(context: Context, uri: Uri): TicketReceiptResult {
        val image = InputImage.fromFilePath(context, uri)
        return analyzeTicketImage(image)
    }

    suspend fun detectBarcodeOnly(image: InputImage): String? {
        val scanner = BarcodeScanning.getClient(barcodeOptions)
        val barcodes = scanner.process(image).awaitResult()
        return barcodes.firstNotNullOfOrNull { it.rawValue?.trim()?.takeIf { v -> v.isNotEmpty() } }
    }

    private suspend fun analyzeProductImage(image: InputImage): ProductOcrResult {
        val barcodeClient = BarcodeScanning.getClient(barcodeOptions)
        val textClient = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        val barcodes = barcodeClient.process(image).awaitResult()
        val visionText = textClient.process(image).awaitResult()

        val detectedBarcode = barcodes.firstNotNullOfOrNull {
            it.rawValue?.trim()?.takeIf { v -> v.isNotEmpty() }
        }.orEmpty()

        return parseProductOcr(visionText.text, detectedBarcode)
    }

    private suspend fun analyzeTicketImage(image: InputImage): TicketReceiptResult {
        val barcodeClient = BarcodeScanning.getClient(barcodeOptions)
        val textClient = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        val barcodes = barcodeClient.process(image).awaitResult()
        val visionText = textClient.process(image).awaitResult()

        val detectedBarcode = barcodes.firstNotNullOfOrNull {
            it.rawValue?.trim()?.takeIf { v -> v.isNotEmpty() }
        }.orEmpty()

        return parseReceiptText(visionText.text, detectedBarcode)
    }

    fun parseProductOcr(rawText: String, mlKitBarcode: String = ""): ProductOcrResult {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }

        val codeBarre = mlKitBarcode.ifBlank {
            extractBarcodeFromText(rawText)
        }

        val reference = extractReferenceFromLines(lines, codeBarre)
        val prix = extractPriceFromLines(lines)
        val designation = extractDesignationFromLines(lines, codeBarre, reference)

        return ProductOcrResult(
            codeBarre = codeBarre,
            reference = reference,
            designation = designation,
            prixFcfa = prix,
            rawText = rawText
        )
    }

    fun parseReceiptText(rawText: String, mlKitBarcode: String = ""): TicketReceiptResult {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }

        val codeBarre = mlKitBarcode.ifBlank {
            extractBarcodeFromText(rawText)
        }

        val numeroTicket = extractTicketNumber(rawText)
        val (dateTimestamp, dateText) = extractDateTimestamp(rawText)
        val montantTotal = extractReceiptTotalAmount(lines)
        val quantite = extractQuantity(lines)

        return TicketReceiptResult(
            codeBarre = codeBarre,
            numeroTicket = numeroTicket,
            dateVenteTimestamp = dateTimestamp,
            dateDetecteeTexte = dateText,
            montantTotalFcfa = montantTotal,
            quantiteDetectee = quantite,
            rawText = rawText
        )
    }

    private fun extractBarcodeFromText(rawText: String): String {
        val regex = Regex("""\b(\d{8}|\d{12,14})\b""")
        return regex.find(rawText)?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun extractReferenceFromLines(lines: List<String>, codeBarre: String): String {
        val explicitRefRegex = Regex(
            """(?i)(?:REF|RÉF|REFERENCE|ART|CODE)\s*[:.#-]?\s*([A-Z0-9][A-Z0-9\-_/]{2,18})"""
        )
        for (line in lines) {
            val match = explicitRefRegex.find(line)
            if (match != null) {
                val candidate = match.groupValues[1].trim()
                if (candidate != codeBarre) return candidate
            }
        }
        val alphaNumCodeRegex = Regex("""\b([A-Z]{2,5}[-/]?[0-9]{2,8})\b""")
        for (line in lines) {
            val match = alphaNumCodeRegex.find(line.uppercase(Locale.FRANCE))
            if (match != null) {
                val candidate = match.groupValues[1]
                if (!candidate.contains("FCFA") && !candidate.contains("CFA")) {
                    return candidate
                }
            }
        }
        return ""
    }

    private fun extractPriceFromLines(lines: List<String>): Long? {
        val currencyRegex = Regex("""(?i)(\d[\d\s.,]{1,12})\s*(?:F\s*CFA|FCFA|CFA|F\b)""")
        val labeledPriceRegex = Regex("""(?i)(?:PRIX|PV|TTC|TARIF|MONTANT)\s*[:=]?\s*(\d[\d\s.,]{1,12})""")

        for (line in lines) {
            currencyRegex.find(line)?.let { match ->
                parseFcfaNumber(match.groupValues[1])?.let { return it }
            }
        }
        for (line in lines) {
            labeledPriceRegex.find(line)?.let { match ->
                parseFcfaNumber(match.groupValues[1])?.let { return it }
            }
        }
        return lines
            .mapNotNull { line ->
                val trimmed = line.replace(" ", "")
                if (trimmed.length in 3..8 && trimmed.all { it.isDigit() }) {
                    trimmed.toLongOrNull()
                } else null
            }
            .firstOrNull { it in 100L..50_000_000L }
    }

    private fun extractDesignationFromLines(
        lines: List<String>,
        codeBarre: String,
        reference: String
    ): String {
        val ignoredKeywords = listOf(
            "ORCA DECO", "ORCA", "MARCORY", "RIVIERA", "YOPOUGON",
            "FCFA", "CFA", "PRIX", "TTC", "TVA", "TICKET", "TOTAL", "ABIDJAN"
        )
        val refUpper = reference.uppercase(Locale.FRANCE)
        return lines.firstOrNull { line ->
            val upper = line.uppercase(Locale.FRANCE)
            val hasLetters = line.any { it.isLetter() }
            val notIgnored = ignoredKeywords.none { upper.contains(it) }
            val isRefLine = upper.startsWith("REF") ||
                upper.startsWith("RÉF") ||
                upper.startsWith("CODE") ||
                (refUpper.isNotEmpty() && upper.contains(refUpper))
            val notCode = line != codeBarre && !isRefLine
            hasLetters && notIgnored && notCode && line.length >= 4
        }.orEmpty()
    }

    private fun extractTicketNumber(rawText: String): String {
        val patterns = listOf(
            Regex("""(?i)(?:TICKET|TKT|RECU|REÇU|FACTURE|BON)\s*(?:N[°O]?|#|:)?\s*([A-Z0-9\-/]{3,20})"""),
            Regex("""(?i)N[°O]\s*[:#]?\s*([A-Z0-9\-/]{4,20})"""),
            Regex("""(?i)CAISSE\s*\d+\s*[-/#:]\s*([A-Z0-9\-/]{3,16})""")
        )
        for (pattern in patterns) {
            val match = pattern.find(rawText)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return "TKT-${(System.currentTimeMillis() % 100000).toString().padStart(5, '0')}"
    }

    private fun extractDateTimestamp(rawText: String): Pair<Long, String> {
        val dmyPattern = Regex("""\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})(?:\s+(?:à\s*)?(\d{1,2})[:h](\d{2}))?\b""")
        val ymdPattern = Regex("""\b(\d{4})[/.\-](\d{1,2})[/.\-](\d{1,2})(?:\s+(\d{1,2})[:h](\d{2}))?\b""")

        dmyPattern.find(rawText)?.let { m ->
            val day = m.groupValues[1].toIntOrNull() ?: return@let
            val month = m.groupValues[2].toIntOrNull() ?: return@let
            var year = m.groupValues[3].toIntOrNull() ?: return@let
            if (year < 100) year += 2000
            val hour = m.groupValues.getOrNull(4)?.toIntOrNull() ?: 12
            val minute = m.groupValues.getOrNull(5)?.toIntOrNull() ?: 0

            if (day in 1..31 && month in 1..12 && year in 2015..2040) {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month - 1)
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                    set(Calendar.MINUTE, minute.coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val formatted = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(cal.time)
                return cal.timeInMillis to formatted
            }
        }

        ymdPattern.find(rawText)?.let { m ->
            val year = m.groupValues[1].toIntOrNull() ?: return@let
            val month = m.groupValues[2].toIntOrNull() ?: return@let
            val day = m.groupValues[3].toIntOrNull() ?: return@let
            val hour = m.groupValues.getOrNull(4)?.toIntOrNull() ?: 12
            val minute = m.groupValues.getOrNull(5)?.toIntOrNull() ?: 0

            if (day in 1..31 && month in 1..12 && year in 2015..2040) {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month - 1)
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                    set(Calendar.MINUTE, minute.coerceIn(0, 59))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val formatted = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(cal.time)
                return cal.timeInMillis to formatted
            }
        }

        val now = System.currentTimeMillis()
        return now to ""
    }

    private fun extractReceiptTotalAmount(lines: List<String>): Long? {
        val totalLineKeywords = listOf(
            "NET A PAYER", "NET À PAYER", "TOTAL TTC", "TOTAL A PAYER",
            "TOTAL", "MONTANT", "A PAYER", "TTC", "SOUS-TOTAL", "SOUS TOTAL"
        )
        val numberRegex = Regex("""(\d[\d\s.,]{1,12})""")

        for (keyword in totalLineKeywords) {
            val matchingLine = lines.lastOrNull {
                it.uppercase(Locale.FRANCE).contains(keyword) &&
                    !it.uppercase(Locale.FRANCE).contains("TVA")
            }
            if (matchingLine != null) {
                val amounts = numberRegex.findAll(matchingLine)
                    .mapNotNull { parseFcfaNumber(it.groupValues[1]) }
                    .filter { it >= 50L }
                    .toList()
                if (amounts.isNotEmpty()) {
                    return amounts.maxOrNull()
                }
            }
        }

        val currencyRegex = Regex("""(?i)(\d[\d\s.,]{1,12})\s*(?:F\s*CFA|FCFA|CFA)""")
        val currencyAmounts = lines.mapNotNull { line ->
            currencyRegex.find(line)?.let { parseFcfaNumber(it.groupValues[1]) }
        }
        return currencyAmounts.maxOrNull()
    }

    private fun extractQuantity(lines: List<String>): Int {
        val qtyRegex = Regex("""(?i)(?:QTE|QTÉ|QUANTITE|QTY)\s*[:=]?\s*(\d{1,3})""")
        for (line in lines) {
            qtyRegex.find(line)?.let { m ->
                val q = m.groupValues[1].toIntOrNull()
                if (q != null && q in 1..999) return q
            }
        }
        val multRegex = Regex("""(?i)\b(\d{1,2})\s*[xX*]\s*\d[\d\s.,]{2,10}""")
        for (line in lines) {
            multRegex.find(line)?.let { m ->
                val q = m.groupValues[1].toIntOrNull()
                if (q != null && q in 1..99) return q
            }
        }
        return 1
    }

    fun parseFcfaNumber(raw: String): Long? {
        val cleaned = raw
            .replace("\u00A0", "")
            .replace(" ", "")
            .trim()
        if (cleaned.isEmpty()) return null

        // Handle thousand separators like 45.000 or 45,000 vs decimal .00
        val normalized = when {
            cleaned.matches(Regex("""\d{1,3}([.,]\d{3})+""")) ->
                cleaned.replace(".", "").replace(",", "")
            cleaned.matches(Regex("""\d+[.,]0{1,2}""")) ->
                cleaned.substringBefore('.').substringBefore(',')
            else ->
                cleaned.replace(".", "").replace(",", "")
        }
        return normalized.toLongOrNull()?.takeIf { it > 0L }
    }

    private suspend fun <T> Task<T>.awaitResult(): T =
        suspendCancellableCoroutine { continuation ->
            addOnSuccessListener { result ->
                if (continuation.isActive) continuation.resume(result)
            }
            addOnFailureListener { exception ->
                if (continuation.isActive) continuation.resumeWithException(exception)
            }
            addOnCanceledListener {
                if (continuation.isActive) continuation.cancel()
            }
        }
}
