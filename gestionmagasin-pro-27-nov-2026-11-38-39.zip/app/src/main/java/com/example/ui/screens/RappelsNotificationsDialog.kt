package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.entity.ArticleEntity
import com.example.data.model.MagasinsOrca
import com.example.notifications.OrcaNotificationHelper
import com.example.notifications.ReminderPreferences
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RappelsNotificationsDialog(
    prefs: ReminderPreferences,
    lowStockArticles: List<ArticleEntity>,
    onDismiss: () -> Unit,
    onUpdateLowStockSettings: (Boolean, Int) -> Unit,
    onScheduleInventoryReminder: (String, Int, Int, String) -> Unit,
    onCancelInventoryReminder: () -> Unit,
    onCheckLowStockNow: () -> Unit,
    onTestInventoryNotification: (String, String) -> Unit
) {
    val context = LocalContext.current
    var hasPermission by remember {
        mutableStateOf(OrcaNotificationHelper.hasNotificationPermission(context))
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
    }

    var lowStockEnabled by remember(prefs) { mutableStateOf(prefs.lowStockAlertsEnabled) }
    var threshold by remember(prefs) { mutableIntStateOf(prefs.lowStockThreshold) }
    var selectedMagasin by remember(prefs) { mutableStateOf(prefs.reminderMagasin) }
    var hour by remember(prefs) { mutableIntStateOf(prefs.reminderHour) }
    var minute by remember(prefs) { mutableIntStateOf(prefs.reminderMinute) }
    var note by remember(prefs) { mutableStateOf(prefs.reminderNote) }
    var showTimePicker by remember { mutableStateOf(false) }

    if (showTimePicker) {
        val timePickerState = rememberTimePickerState(
            initialHour = hour,
            initialMinute = minute,
            is24Hour = true
        )
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text("Heure du rappel quotidien") },
            text = {
                TimePicker(state = timePickerState)
            },
            confirmButton = {
                Button(
                    onClick = {
                        hour = timePickerState.hour
                        minute = timePickerState.minute
                        showTimePicker = false
                    }
                ) {
                    Text("Valider")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Rappels & Alertes Stock",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Permission Android 13+
                if (!hasPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = StatusErrorContainer,
                        border = BorderStroke(1.dp, StatusError)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Autorisez les notifications Android pour recevoir les alertes de stock bas et rappels d'inventaire.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusError,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("grant_notifications_permission_button")
                            ) {
                                Text("Autoriser les notifications")
                            }
                        }
                    }
                }

                // Section 1 : Alertes Stock Bas
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Alertes Stock Bas automatiques",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${lowStockArticles.size} article(s) actuellement ≤ $threshold",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (lowStockArticles.isNotEmpty()) StatusError else StatusSuccess
                                )
                            }
                            Switch(
                                checked = lowStockEnabled,
                                onCheckedChange = { checked ->
                                    lowStockEnabled = checked
                                    onUpdateLowStockSettings(checked, threshold)
                                },
                                modifier = Modifier.testTag("toggle_low_stock_alerts")
                            )
                        }

                        Text(
                            text = "Seuil d'alerte (quantité restante ≤) :",
                            style = MaterialTheme.typography.labelMedium
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1, 2, 3, 5, 10).forEach { value ->
                                FilterChip(
                                    selected = threshold == value,
                                    onClick = {
                                        threshold = value
                                        onUpdateLowStockSettings(lowStockEnabled, value)
                                    },
                                    label = { Text("≤ $value") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }

                        if (lowStockArticles.isNotEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusErrorContainer.copy(alpha = 0.6f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = StatusError,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = lowStockArticles.take(2).joinToString(", ") {
                                            "${it.designation} (${it.quantite})"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StatusError
                                    )
                                }
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                if (!hasPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onCheckLowStockNow()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("notify_low_stock_now_button")
                        ) {
                            Text("Notifier stock bas maintenant")
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Section 2 : Rappel d'Inventaire Programmé
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Rappel Inventaire Programmé",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (prefs.inventoryReminderEnabled) {
                                StatusSuccessContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        ) {
                            Text(
                                text = if (prefs.inventoryReminderEnabled) "ACTIF" else "INACTIF",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (prefs.inventoryReminderEnabled) {
                                    StatusSuccess
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    MagasinSelectorChips(
                        selectedMagasin = selectedMagasin,
                        includeAllOption = true,
                        onSelectMagasin = { selectedMagasin = it }
                    )

                    val formattedTime = String.format(Locale.FRANCE, "%02d:%02d", hour, minute)
                    OutlinedButton(
                        onClick = { showTimePicker = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pick_inventory_reminder_time_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Heure quotidienne : $formattedTime",
                            fontFamily = JetBrainsMonoFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Message du rappel inventaire") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (!hasPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onScheduleInventoryReminder(selectedMagasin, hour, minute, note)
                                }
                            },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("schedule_inventory_reminder_button")
                        ) {
                            Text("Programmer")
                        }

                        if (prefs.inventoryReminderEnabled) {
                            OutlinedButton(
                                onClick = onCancelInventoryReminder,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("cancel_inventory_reminder_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Arrêter")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    if (!hasPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        onTestInventoryNotification(selectedMagasin, note)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("test_inventory_reminder_button")
                            ) {
                                Text("Tester")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fermer")
            }
        }
    )
}
