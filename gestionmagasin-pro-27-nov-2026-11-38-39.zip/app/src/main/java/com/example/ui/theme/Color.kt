package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ORCA DECO Abidjan - Terracotta & Anthracite Palette
val TerracottaPrimary = Color(0xFFB44B27)
val OnTerracotta = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFFFFDBD0)
val OnTerracottaContainer = Color(0xFF3D1103)

val AnthraciteSecondary = Color(0xFF2B2927)
val OnAnthracite = Color(0xFFFFFFFF)
val AnthraciteContainer = Color(0xFFE7E2DC)
val OnAnthraciteContainer = Color(0xFF1C1A18)

val OchreTertiary = Color(0xFFC58B2A)
val OnOchre = Color(0xFFFFFFFF)
val OchreContainer = Color(0xFFFFE6B8)
val OnOchreContainer = Color(0xFF332000)

val WarmLinenBackground = Color(0xFFFAF7F4)
val WarmWhiteSurface = Color(0xFFFFFFFF)
val WarmSandSurfaceVariant = Color(0xFFF2ECE6)
val WarmBorderOutline = Color(0xFFDAD1C8)
val WarmBorderVariant = Color(0xFFE8E0D8)

val InkPrimary = Color(0xFF1F1C1A)
val InkSecondary = Color(0xFF5F5852)

val StatusSuccess = Color(0xFF247A4B)
val StatusSuccessContainer = Color(0xFFD7F2E2)
val StatusError = Color(0xFFBA1A1A)
val StatusErrorContainer = Color(0xFFFFDAD6)

// Dark Theme Tokens
val DarkTerracottaPrimary = Color(0xFFFFB59D)
val DarkOnTerracotta = Color(0xFF601B04)
val DarkTerracottaContainer = Color(0xFF8C3213)
val DarkBackground = Color(0xFF171412)
val DarkSurface = Color(0xFF211D1A)
val DarkSurfaceVariant = Color(0xFF2E2824)
val DarkOnSurface = Color(0xFFF3ECE6)
val DarkOutline = Color(0xFF524841)
