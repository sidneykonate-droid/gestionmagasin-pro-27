package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.entity.ArticleEntity
import com.example.data.model.FormatUtils
import com.example.data.model.MagasinsOrca
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.viewmodel.MagasinViewModel

@Composable
fun BaseArticlesScreen(
    articles: List<ArticleEntity>,
    searchQuery: String,
    selectedMagasin: String,
    viewModel: MagasinViewModel,
    onEditInFormTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    var articleToEdit by remember { mutableStateOf<ArticleEntity?>(null) }
    var articleToDelete by remember { mutableStateOf<ArticleEntity?>(null) }

    articleToEdit?.let { editing ->
        EditArticleDialog(
            article = editing,
            onDismiss = { articleToEdit = null },
            onConfirm = { updated ->
                viewModel.sauvegarderArticleModifie(updated)
                articleToEdit = null
            },
            onOpenFullForm = {
                viewModel.chargerArticleDansFormulaire(editing)
                articleToEdit = null
                onEditInFormTab()
            }
        )
    }

    articleToDelete?.let { deleting ->
        AlertDialog(
            onDismissRequest = { articleToDelete = null },
            title = { Text("Supprimer l'article ?") },
            text = {
                Text("Voulez-vous vraiment supprimer « ${deleting.designation} » (${deleting.codeBarre}) du site ${deleting.magasin} ?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.supprimerArticle(deleting)
                        articleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_article_button")
                ) {
                    Text("Supprimer")
                }
            },
            dismissButton = {
                TextButton(onClick = { articleToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp)
                .padding(top = 14.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateBaseSearchQuery(it) },
                placeholder = { Text("Rechercher code-barres, référence, désignation...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateBaseSearchQuery("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Effacer recherche")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("base_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            MagasinSelectorChips(
                selectedMagasin = selectedMagasin,
                includeAllOption = true,
                onSelectMagasin = { viewModel.updateBaseMagasinFilter(it) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            val totalUnits = remember(articles) { articles.sumOf { it.quantite } }
            val totalValue = remember(articles) { articles.sumOf { it.prixFcfa * it.quantite } }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${articles.size} référence(s) • $totalUnits unités",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = FormatUtils.formatFcfa(totalValue),
                        fontFamily = JetBrainsMonoFamily,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }

        if (articles.isEmpty()) {
            EmptyStateCard(
                icon = Icons.Default.Inventory,
                title = "Aucun article dans cette vue",
                description = "Ajoutez un produit via l'onglet OCR / Saisie ou modifiez vos critères de recherche.",
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .padding(top = 12.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp),
                contentPadding = PaddingValues(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(articles, key = { it.id }) { article ->
                    ArticleStockCard(
                        article = article,
                        onEdit = { articleToEdit = article },
                        onDelete = { articleToDelete = article }
                    )
                }
            }
        }
    }
}

@Composable
private fun ArticleStockCard(
    article: ArticleEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isLowStock = article.quantite <= 2

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("article_card_${article.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = article.designation,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MonospaceCodeBadge(label = "Réf: ${article.reference}")
                        MonospaceCodeBadge(label = "CB: ${article.codeBarre}")
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isLowStock) StatusErrorContainer else StatusSuccessContainer
                ) {
                    Text(
                        text = "Stock: ${article.quantite}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isLowStock) StatusError else StatusSuccess,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = FormatUtils.formatFcfa(article.prixFcfa),
                        fontFamily = JetBrainsMonoFamily,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${MagasinsOrca.shortLabel(article.magasin)} • MAJ ${FormatUtils.formatDate(article.dateMaj)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("edit_article_${article.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Modifier l'article",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("delete_article_${article.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Supprimer l'article",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditArticleDialog(
    article: ArticleEntity,
    onDismiss: () -> Unit,
    onConfirm: (ArticleEntity) -> Unit,
    onOpenFullForm: () -> Unit
) {
    var designation by remember { mutableStateOf(article.designation) }
    var reference by remember { mutableStateOf(article.reference) }
    var codeBarre by remember { mutableStateOf(article.codeBarre) }
    var prixText by remember { mutableStateOf(article.prixFcfa.toString()) }
    var quantiteText by remember { mutableStateOf(article.quantite.toString()) }
    var magasin by remember { mutableStateOf(article.magasin) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modifier l'article") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MagasinSelectorChips(
                    selectedMagasin = magasin,
                    includeAllOption = false,
                    onSelectMagasin = { magasin = it }
                )
                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    label = { Text("Désignation") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reference,
                    onValueChange = { reference = it },
                    label = { Text("Référence") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = codeBarre,
                    onValueChange = { codeBarre = it },
                    label = { Text("Code-barres") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = prixText,
                        onValueChange = { prixText = it.filter { c -> c.isDigit() } },
                        label = { Text("Prix FCFA") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1.2f)
                    )
                    OutlinedTextField(
                        value = quantiteText,
                        onValueChange = { quantiteText = it.filter { c -> c.isDigit() } },
                        label = { Text("Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                }
                TextButton(onClick = onOpenFullForm) {
                    Text("Ouvrir dans l'onglet OCR / Saisie")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val prix = prixText.toLongOrNull() ?: article.prixFcfa
                    val qty = quantiteText.toIntOrNull() ?: article.quantite
                    onConfirm(
                        article.copy(
                            designation = designation.trim().ifEmpty { article.designation },
                            reference = reference.trim().ifEmpty { article.reference },
                            codeBarre = codeBarre.trim().ifEmpty { article.codeBarre },
                            prixFcfa = prix,
                            quantite = qty,
                            magasin = magasin,
                            dateMaj = System.currentTimeMillis()
                        )
                    )
                }
            ) {
                Text("Valider")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}
