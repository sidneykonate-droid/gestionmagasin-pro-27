package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.roundToInt
import com.example.data.model.FormatUtils
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.MonthlySalesPoint
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.component.shapeComponent
import com.patrykandpatrick.vico.compose.component.shape.shader.fromBrush
import com.patrykandpatrick.vico.compose.m3.style.m3ChartStyle
import com.patrykandpatrick.vico.compose.style.ProvideChartStyle
import com.patrykandpatrick.vico.core.axis.AxisPosition
import com.patrykandpatrick.vico.core.axis.formatter.AxisValueFormatter
import com.patrykandpatrick.vico.core.component.shape.LineComponent
import com.patrykandpatrick.vico.core.component.shape.Shapes
import com.patrykandpatrick.vico.core.component.shape.shader.DynamicShaders
import com.patrykandpatrick.vico.core.entry.ChartEntryModelProducer
import com.patrykandpatrick.vico.core.entry.entryOf
import java.util.Locale

@Composable
fun VentesMensuellesChartCard(
    monthlyPoints: List<MonthlySalesPoint>,
    modifier: Modifier = Modifier
) {
    val modelProducer = remember { ChartEntryModelProducer() }
    val primaryColor = MaterialTheme.colorScheme.primary
    val guidelineArgb = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f).toArgb()

    LaunchedEffect(monthlyPoints) {
        val entries = monthlyPoints.mapIndexed { index, point ->
            entryOf(index.toFloat(), point.totalFcfa.toFloat())
        }
        modelProducer.setEntries(entries)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("monthly_sales_chart_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ShowChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Évolution Mensuelle des Ventes",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (monthlyPoints.isEmpty()) {
                                "Aucune vente sur la sélection"
                            } else {
                                "${monthlyPoints.size} mois • Chiffre d'affaires en FCFA"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                monthlyPoints.maxByOrNull { it.totalFcfa }?.let { peak ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "Pic : ${peak.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (monthlyPoints.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Courbe mensuelle en attente de données",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Validez des tickets de caisse pour tracer la progression des ventes par mois.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                val bottomAxisValueFormatter = remember(monthlyPoints) {
                    AxisValueFormatter<AxisPosition.Horizontal.Bottom> { value, _ ->
                        val rounded = value.roundToInt()
                        if (abs(value - rounded) < 0.05f) {
                            monthlyPoints.getOrNull(rounded)?.label.orEmpty()
                        } else {
                            ""
                        }
                    }
                }

                val startAxisValueFormatter = remember {
                    AxisValueFormatter<AxisPosition.Vertical.Start> { value, _ ->
                        formatCompactFcfa(value.toLong())
                    }
                }

                ProvideChartStyle(m3ChartStyle(entityColors = listOf(primaryColor))) {
                    Chart(
                        chart = lineChart(
                            lines = listOf(
                                lineSpec(
                                    lineColor = primaryColor,
                                    lineThickness = 3.dp,
                                    lineBackgroundShader = DynamicShaders.fromBrush(
                                        Brush.verticalGradient(
                                            listOf(
                                                primaryColor.copy(alpha = 0.35f),
                                                primaryColor.copy(alpha = 0.02f)
                                            )
                                        )
                                    ),
                                    point = shapeComponent(
                                        shape = Shapes.pillShape,
                                        color = primaryColor
                                    ),
                                    pointSize = 8.dp
                                )
                            )
                        ),
                        chartModelProducer = modelProducer,
                        startAxis = rememberStartAxis(
                            valueFormatter = startAxisValueFormatter,
                            guideline = LineComponent(
                                color = guidelineArgb,
                                thicknessDp = 0.6f
                            )
                        ),
                        bottomAxis = rememberBottomAxis(
                            valueFormatter = bottomAxisValueFormatter,
                            guideline = null
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                            .testTag("vico_monthly_line_chart")
                    )
                }

                // Détail chiffré par mois
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    monthlyPoints.forEach { pt ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text(
                                    text = pt.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = FormatUtils.formatFcfa(pt.totalFcfa),
                                    fontFamily = JetBrainsMonoFamily,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${pt.ticketCount} ticket(s) • ${pt.quantite} u.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatCompactFcfa(amount: Long): String {
    return when {
        amount >= 1_000_000L -> String.format(Locale.FRANCE, "%.1fM", amount / 1_000_000.0)
        amount >= 1_000L -> "${amount / 1_000L}k"
        else -> "$amount"
    }
}
