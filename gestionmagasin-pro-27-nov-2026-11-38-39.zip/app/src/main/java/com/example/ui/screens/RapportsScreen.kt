package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.entity.ArticleEntity
import com.example.data.entity.VenteTicketEntity
import com.example.data.model.FormatUtils
import com.example.data.model.MagasinsOrca
import com.example.export.RapportKpiSummary
import com.example.scanner.CameraScannerDialog
import com.example.scanner.ScannerMode
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.viewmodel.MagasinViewModel
import com.example.viewmodel.MonthlySalesPoint
import com.example.viewmodel.PendingTicketValidation
import com.example.viewmodel.PeriodeFiltre
import com.example.viewmodel.RapportsFilterState
import java.util.Calendar
import java.util.TimeZone

private enum class DateTarget {
    RANGE_START,
    RANGE_END,
    TICKET_DATE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RapportsScreen(
    ventes: List<VenteTicketEntity>,
    allArticles: List<ArticleEntity>,
    filterState: RapportsFilterState,
    kpi: RapportKpiSummary,
    monthlyPoints: List<MonthlySalesPoint>,
    pendingTicket: PendingTicketValidation?,
    isBusy: Boolean,
    viewModel: MagasinViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showTicketScanner by remember { mutableStateOf(false) }
    var activeDateTarget by remember { mutableStateOf<DateTarget?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.analyzeTicketUri(context, uri)
        }
    }

    if (showTicketScanner) {
        CameraScannerDialog(
            mode = ScannerMode.TICKET,
            onDismiss = { showTicketScanner = false },
            onBitmapCaptured = { bitmap ->
                showTicketScanner = false
                viewModel.analyzeTicketBitmap(bitmap)
            }
        )
    }

    activeDateTarget?.let { target ->
        val initialMillis = when (target) {
            DateTarget.RANGE_START -> localMillisToUtcPickerMillis(filterState.customStartMillis)
            DateTarget.RANGE_END -> localMillisToUtcPickerMillis(filterState.customEndMillis)
            DateTarget.TICKET_DATE -> localMillisToUtcPickerMillis(
                pendingTicket?.dateVenteTimestamp ?: System.currentTimeMillis()
            )
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)

        DatePickerDialog(
            onDismissRequest = { activeDateTarget = null },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { utcMillis ->
                            val localMillis = utcPickerMillisToLocalNoon(utcMillis)
                            when (target) {
                                DateTarget.RANGE_START -> viewModel.updateRapportsCustomStart(localMillis)
                                DateTarget.RANGE_END -> viewModel.updateRapportsCustomEnd(localMillis)
                                DateTarget.TICKET_DATE -> viewModel.updatePendingTicket {
                                    it.copy(dateVenteTimestamp = localMillis)
                                }
                            }
                        }
                        activeDateTarget = null
                    }
                ) {
                    Text("Confirmer")
                }
            },
            dismissButton = {
                TextButton(onClick = { activeDateTarget = null }) {
                    Text("Annuler")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    pendingTicket?.let { ticket ->
        TicketValidationDialog(
            ticket = ticket,
            allArticles = allArticles,
            onUpdate = { viewModel.updatePendingTicket(it) },
            onLookupBarcode = { viewModel.lookupArticleForPendingTicket(it) },
            onSelectArticle = { viewModel.associerArticleAuTicket(it) },
            onOpenDatePicker = { activeDateTarget = DateTarget.TICKET_DATE },
            onConfirm = { viewModel.confirmerValidationTicket() },
            onDismiss = { viewModel.annulerValidationTicket() }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Acquisition Ticket de caisse
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Lecture Ticket de Caisse (ML Kit)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Extrait code-barres, date réelle de vente, numéro de ticket et montant FCFA, puis met à jour le stock.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { showTicketScanner = true },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("scanner_ticket_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scanner Ticket", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !isBusy,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("photo_ticket_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Photo Ticket", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // KPI Cards
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiCard(
                        title = "Quantité Vendue",
                        value = "${kpi.quantiteTotaleVendue}",
                        subtitle = "${kpi.nombreTickets} ticket(s)",
                        accentColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "CA Tickets",
                        value = FormatUtils.formatFcfa(kpi.chiffreAffairesFcfa),
                        subtitle = "Période active",
                        accentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1.3f)
                    )
                }
                KpiCard(
                    title = "Valorisation du Stock Actuel",
                    value = FormatUtils.formatFcfa(kpi.valorisationStockFcfa),
                    subtitle = "Site : ${filterState.magasin}",
                    accentColor = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Graphique linéaire mensuel des ventes (Vico Compose M3)
        item {
            VentesMensuellesChartCard(
                monthlyPoints = monthlyPoints,
                modifier = Modifier.widthIn(max = 720.dp)
            )
        }

        // Filtres Période, Site, Produit
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Filtres d'analyse",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    // Périodes
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PeriodeFiltre.entries.forEach { periode ->
                            val selected = filterState.periode == periode
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.updateRapportsPeriode(periode) },
                                label = { Text(periode.label) },
                                leadingIcon = if (selected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }

                    // Plage personnalisée multi-années Du / Au
                    if (filterState.periode == PeriodeFiltre.DATE_PRECISE_LONGUE_DATE) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { activeDateTarget = DateTarget.RANGE_START },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("custom_start_date_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Du : ${FormatUtils.formatDate(filterState.customStartMillis)}")
                            }
                            OutlinedButton(
                                onClick = { activeDateTarget = DateTarget.RANGE_END },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("custom_end_date_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Au : ${FormatUtils.formatDate(filterState.customEndMillis)}")
                            }
                        }
                    }

                    // Site ORCA DECO
                    MagasinSelectorChips(
                        selectedMagasin = filterState.magasin,
                        includeAllOption = true,
                        onSelectMagasin = { viewModel.updateRapportsMagasin(it) }
                    )

                    // Filtre par code-barres ou désignation article
                    OutlinedTextField(
                        value = filterState.produitQuery,
                        onValueChange = { viewModel.updateRapportsProduitQuery(it) },
                        label = { Text("Filtrer par code-barres ou désignation produit") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (filterState.produitQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateRapportsProduitQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Effacer")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rapport_product_filter_input")
                    )

                    // Export PDF A4 + WhatsApp
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.exporterRapportPdf(context) },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("export_pdf_report_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rapport PDF A4")
                        }

                        Button(
                            onClick = { viewModel.partagerRapportWhatsApp(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusSuccess
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("share_whatsapp_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("WhatsApp")
                        }
                    }
                }
            }
        }

        // Récapitulatif des dates de vente d'un produit précis
        if (filterState.produitQuery.isNotBlank() && ventes.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 720.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Dates de vente pour « ${filterState.produitQuery} »",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        val datesResume = ventes
                            .map { "${FormatUtils.formatDate(it.dateVenteTimestamp)} (${it.quantiteVendue}x • ${MagasinsOrca.shortLabel(it.magasin)})" }
                            .joinToString("  •  ")
                        Text(
                            text = datesResume,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        // Liste des ventes tickets
        if (ventes.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.AutoMirrored.Filled.ReceiptLong,
                    title = "Aucune vente sur cette période",
                    description = "Scannez un ticket de caisse ou sélectionnez une photo de ticket pour enregistrer les ventes et suivre votre chiffre d'affaires.",
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        } else {
            items(ventes, key = { it.id }) { vente ->
                VenteTicketCard(
                    vente = vente,
                    onDelete = { viewModel.supprimerVente(vente) },
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontFamily = JetBrainsMonoFamily,
                style = MaterialTheme.typography.titleMedium,
                color = accentColor,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun VenteTicketCard(
    vente: VenteTicketEntity,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MonospaceCodeBadge(
                        label = vente.numeroTicket,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    MonospaceCodeBadge(label = FormatUtils.formatDate(vente.dateVenteTimestamp))
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Supprimer le ticket",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            Text(
                text = vente.designation,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            if (vente.codeBarre.isNotBlank()) {
                Text(
                    text = "CB: ${vente.codeBarre} • Réf: ${vente.reference.ifBlank { "-" }}",
                    fontFamily = JetBrainsMonoFamily,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${MagasinsOrca.shortLabel(vente.magasin)} • Qté: ${vente.quantiteVendue}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = FormatUtils.formatFcfa(vente.montantTotalFcfa),
                    fontFamily = JetBrainsMonoFamily,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun TicketValidationDialog(
    ticket: PendingTicketValidation,
    allArticles: List<ArticleEntity>,
    onUpdate: ((PendingTicketValidation) -> PendingTicketValidation) -> Unit,
    onLookupBarcode: (String) -> Unit,
    onSelectArticle: (ArticleEntity) -> Unit,
    onOpenDatePicker: () -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    var showArticlePicker by remember { mutableStateOf(false) }

    if (showArticlePicker) {
        AlertDialog(
            onDismissRequest = { showArticlePicker = false },
            title = { Text("Associer un article en base") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (allArticles.isEmpty()) {
                        Text("Aucun article en base pour l'instant.")
                    } else {
                        allArticles.forEach { art ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSelectArticle(art)
                                        showArticlePicker = false
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(art.designation, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${art.codeBarre} • ${FormatUtils.formatFcfa(art.prixFcfa)} • Stock: ${art.quantite}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showArticlePicker = false }) {
                    Text("Fermer")
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Validation Ticket de Caisse",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (ticket.matchedArticle != null) {
                        StatusSuccessContainer
                    } else {
                        MaterialTheme.colorScheme.tertiaryContainer
                    }
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = if (ticket.matchedArticle != null) {
                                "Article associé en base : ${ticket.matchedArticle.designation} (Stock actuel : ${ticket.matchedArticle.quantite})"
                            } else {
                                "Aucun article associé automatiquement par code-barres. Associez-le ou complétez ci-dessous."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (ticket.matchedArticle != null) {
                                StatusSuccess
                            } else {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { showArticlePicker = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Link,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Choisir un article en base")
                        }
                    }
                }

                MagasinSelectorChips(
                    selectedMagasin = ticket.magasin,
                    includeAllOption = false,
                    onSelectMagasin = { site ->
                        onUpdate { it.copy(magasin = site) }
                    }
                )

                // Date de vente via DatePickerDialog
                OutlinedButton(
                    onClick = onOpenDatePicker,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ticket_validation_date_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Date de vente : ${FormatUtils.formatDate(ticket.dateVenteTimestamp)}",
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = ticket.codeBarre,
                        onValueChange = { cb -> onUpdate { it.copy(codeBarre = cb) } },
                        label = { Text("Code-barres") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { onLookupBarcode(ticket.codeBarre) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Associer par code-barres")
                    }
                }

                OutlinedTextField(
                    value = ticket.numeroTicket,
                    onValueChange = { num -> onUpdate { it.copy(numeroTicket = num) } },
                    label = { Text("Numéro de ticket") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ticket.designation,
                    onValueChange = { des -> onUpdate { it.copy(designation = des) } },
                    label = { Text("Désignation article") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ticket.quantiteVendueText,
                        onValueChange = { qText ->
                            val clean = qText.filter { it.isDigit() }
                            val q = clean.toIntOrNull() ?: 1
                            val unit = ticket.prixUnitaireFcfaText.toLongOrNull() ?: 0L
                            onUpdate {
                                it.copy(
                                    quantiteVendueText = clean,
                                    montantTotalFcfaText = if (unit > 0L) (unit * q).toString() else it.montantTotalFcfaText
                                )
                            }
                        },
                        label = { Text("Qté") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                    OutlinedTextField(
                        value = ticket.montantTotalFcfaText,
                        onValueChange = { amt ->
                            onUpdate { it.copy(montantTotalFcfaText = amt.filter { c -> c.isDigit() }) }
                        },
                        label = { Text("Montant (FCFA)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1.4f)
                    )
                }

                Text(
                    text = "La confirmation déduira automatiquement la quantité vendue du stock en base.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_ticket_validation_button")
            ) {
                Text("Valider la vente")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}

private fun localMillisToUtcPickerMillis(localMillis: Long): Long {
    val localCal = Calendar.getInstance().apply { timeInMillis = localMillis }
    val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        set(Calendar.YEAR, localCal.get(Calendar.YEAR))
        set(Calendar.MONTH, localCal.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, localCal.get(Calendar.DAY_OF_MONTH))
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return utcCal.timeInMillis
}

private fun utcPickerMillisToLocalNoon(utcMillis: Long): Long {
    val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMillis }
    val localCal = Calendar.getInstance().apply {
        set(Calendar.YEAR, utcCal.get(Calendar.YEAR))
        set(Calendar.MONTH, utcCal.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, utcCal.get(Calendar.DAY_OF_MONTH))
        set(Calendar.HOUR_OF_DAY, 12)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return localCal.timeInMillis
}
