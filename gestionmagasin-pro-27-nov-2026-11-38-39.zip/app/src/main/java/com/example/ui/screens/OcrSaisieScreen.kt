package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.scanner.CameraScannerDialog
import com.example.scanner.ScannerMode
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.viewmodel.MagasinViewModel
import com.example.viewmodel.OcrFormState

@Composable
fun OcrSaisieScreen(
    formState: OcrFormState,
    viewModel: MagasinViewModel,
    modifier: Modifier = Modifier
) {
    var showCameraScanner by remember { mutableStateOf(false) }

    if (showCameraScanner) {
        CameraScannerDialog(
            mode = ScannerMode.ARTICLE,
            onDismiss = { showCameraScanner = false },
            onBitmapCaptured = { bitmap ->
                showCameraScanner = false
                viewModel.analyzeArticleBitmap(bitmap)
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Carte Hero Scan ML Kit
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.secondary,
                                    MaterialTheme.colorScheme.primary
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Acquisition Rapide ML Kit",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Scannez une étiquette rayon pour pré-remplir code-barres, référence, désignation et prix FCFA.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFFFE5DC)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = Color(0xFFFFE5DC),
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { showCameraScanner = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("scan_article_camera_button")
                    ) {
                        Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Scanner avec la caméra",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Message retour OCR / recherche
            AnimatedVisibility(visible = !formState.scanInfoMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (formState.existingMatchFound) {
                        StatusSuccessContainer
                    } else {
                        MaterialTheme.colorScheme.tertiaryContainer
                    },
                    border = BorderStroke(
                        1.dp,
                        if (formState.existingMatchFound) StatusSuccess else MaterialTheme.colorScheme.tertiary
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (formState.existingMatchFound) {
                                StatusSuccess
                            } else {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = formState.scanInfoMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (formState.existingMatchFound) {
                                StatusSuccess
                            } else {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            },
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Sélecteur magasin ORCA DECO
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Site ORCA DECO Abidjan",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    MagasinSelectorChips(
                        selectedMagasin = formState.magasin,
                        includeAllOption = false,
                        onSelectMagasin = { site ->
                            viewModel.updateOcrForm(magasin = site)
                        }
                    )
                }
            }

            // Formulaire complet Article
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Inventory2,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (formState.editingId > 0L) {
                                    "Modification Article"
                                } else {
                                    "Fiche Article"
                                },
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        if (formState.editingId > 0L || formState.codeBarre.isNotEmpty() || formState.designation.isNotEmpty()) {
                            OutlinedButton(
                                onClick = { viewModel.resetOcrForm() },
                                modifier = Modifier.testTag("reset_ocr_form_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Réinitialiser",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Nouveau")
                            }
                        }
                    }

                    // Code-barres + recherche instantanée
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = formState.codeBarre,
                            onValueChange = { viewModel.updateOcrForm(codeBarre = it) },
                            label = { Text("Code-barres (EAN / Code128)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Ascii,
                                imeAction = ImeAction.Search
                            ),
                            keyboardActions = KeyboardActions(
                                onSearch = { viewModel.rechercherInstantaneParCodeBarre() }
                            ),
                            trailingIcon = {
                                if (formState.codeBarre.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.updateOcrForm(codeBarre = "") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Effacer code-barres")
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_code_barre")
                        )

                        Button(
                            onClick = { viewModel.rechercherInstantaneParCodeBarre() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            ),
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("instant_barcode_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Rechercher par code-barres"
                            )
                        }
                    }

                    OutlinedTextField(
                        value = formState.reference,
                        onValueChange = { viewModel.updateOcrForm(reference = it) },
                        label = { Text("Référence produit (ex: ORC-458)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_reference")
                    )

                    OutlinedTextField(
                        value = formState.designation,
                        onValueChange = { viewModel.updateOcrForm(designation = it) },
                        label = { Text("Désignation complète") },
                        maxLines = 2,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_designation")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = formState.prixFcfaText,
                            onValueChange = { input ->
                                viewModel.updateOcrForm(prixFcfaText = input.filter { it.isDigit() })
                            },
                            label = { Text("Prix (FCFA)") },
                            singleLine = true,
                            suffix = { Text("FCFA") },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .weight(1.4f)
                                .testTag("input_prix_fcfa")
                        )

                        OutlinedTextField(
                            value = formState.quantiteText,
                            onValueChange = { input ->
                                viewModel.updateOcrForm(quantiteText = input.filter { it.isDigit() })
                            },
                            label = { Text("Quantité") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Done
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_quantite")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { viewModel.enregistrerArticle() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("save_article_button")
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (formState.editingId > 0L) {
                                "Mettre à jour en base"
                            } else {
                                "Enregistrer dans la base"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
