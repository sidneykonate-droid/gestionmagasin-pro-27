package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    onPrimary = OnTerracotta,
    primaryContainer = TerracottaContainer,
    onPrimaryContainer = OnTerracottaContainer,
    secondary = AnthraciteSecondary,
    onSecondary = OnAnthracite,
    secondaryContainer = AnthraciteContainer,
    onSecondaryContainer = OnAnthraciteContainer,
    tertiary = OchreTertiary,
    onTertiary = OnOchre,
    tertiaryContainer = OchreContainer,
    onTertiaryContainer = OnOchreContainer,
    background = WarmLinenBackground,
    onBackground = InkPrimary,
    surface = WarmWhiteSurface,
    onSurface = InkPrimary,
    surfaceVariant = WarmSandSurfaceVariant,
    onSurfaceVariant = InkSecondary,
    outline = WarmBorderOutline,
    outlineVariant = WarmBorderVariant,
    error = StatusError,
    errorContainer = StatusErrorContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkTerracottaPrimary,
    onPrimary = DarkOnTerracotta,
    primaryContainer = DarkTerracottaContainer,
    onPrimaryContainer = TerracottaContainer,
    secondary = AnthraciteContainer,
    onSecondary = AnthraciteSecondary,
    tertiary = OchreTertiary,
    onTertiary = OnOchre,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = AnthraciteContainer,
    outline = DarkOutline
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun GestionMagasinTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme && isSystemInDarkTheme()) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
