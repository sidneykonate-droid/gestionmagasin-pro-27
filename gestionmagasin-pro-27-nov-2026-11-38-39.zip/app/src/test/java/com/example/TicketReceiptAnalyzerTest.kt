package com.example

import com.example.data.model.FormatUtils
import com.example.data.model.MagasinsOrca
import com.example.scanner.TicketReceiptAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TicketReceiptAnalyzerTest {

    @Test
    fun `parseReceiptText extracts ticket number date amount and barcode`() {
        val sampleReceipt = """
            ORCA DECO ABIDJAN - MARCORY
            Ticket N° TKT-84920
            Date : 14/03/2024 15:42
            CANAPE VELOURS 3 PLACES
            QTE : 2
            TOTAL TTC : 350 000 FCFA
            3254580012345
        """.trimIndent()

        val result = TicketReceiptAnalyzer.parseReceiptText(sampleReceipt)

        assertEquals("TKT-84920", result.numeroTicket)
        assertEquals("3254580012345", result.codeBarre)
        assertEquals(350000L, result.montantTotalFcfa)
        assertEquals(2, result.quantiteDetectee)
        assertEquals("14/03/2024", result.dateDetecteeTexte)
        val formatted = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(result.dateVenteTimestamp))
        assertEquals("14/03/2024", formatted)
    }

    @Test
    fun `parseReceiptText supports historical multi-year dates`() {
        val oldReceipt = """
            ORCA DECO YOPOUGON KOUTE
            RECU #REC-2021-99
            19/11/2021 09:15
            NET A PAYER 75 500 FCFA
        """.trimIndent()

        val result = TicketReceiptAnalyzer.parseReceiptText(oldReceipt, "6180000112233")

        assertEquals("6180000112233", result.codeBarre)
        assertEquals("REC-2021-99", result.numeroTicket)
        assertEquals(75500L, result.montantTotalFcfa)
        assertEquals("19/11/2021", result.dateDetecteeTexte)
    }

    @Test
    fun `parseProductOcr extracts reference designation and price`() {
        val sampleLabel = """
            ORCA DECO RIVIERA MALL
            REF: ORC-7742
            Table Basse Chêne Massif
            Prix : 125.000 FCFA
        """.trimIndent()

        val result = TicketReceiptAnalyzer.parseProductOcr(sampleLabel, "6181234567890")

        assertEquals("6181234567890", result.codeBarre)
        assertEquals("ORC-7742", result.reference)
        assertTrue(result.designation.contains("Table Basse"))
        assertEquals(125000L, result.prixFcfa)
    }

    @Test
    fun `formatFcfa and Orca stores are consistent`() {
        assertEquals(3, MagasinsOrca.SITES.size)
        assertTrue(MagasinsOrca.SITES.contains(MagasinsOrca.MARCORY))
        assertTrue(MagasinsOrca.SITES.contains(MagasinsOrca.RIVIERA))
        assertTrue(MagasinsOrca.SITES.contains(MagasinsOrca.YOPOUGON))
        assertTrue(FormatUtils.formatFcfa(125000L).endsWith("FCFA"))
    }
}
