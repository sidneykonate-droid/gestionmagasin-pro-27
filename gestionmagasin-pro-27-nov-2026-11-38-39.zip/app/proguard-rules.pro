# GestionMagasin Pro - R8 / ProGuard rules
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Apache POI + XMLBeans + Aalto-XML + StAX API (charged dynamically via System.setProperty)
-keep class com.fasterxml.aalto.** { *; }
-keep class org.codehaus.stax2.** { *; }
-keep class javax.xml.stream.** { *; }
-keep class org.apache.poi.** { *; }
-keep class org.openxmlformats.schemas.** { *; }
-keep class org.apache.xmlbeans.** { *; }
-keep class com.example.data.entity.** { *; }

-dontwarn java.awt.**
-dontwarn javax.awt.**
-dontwarn javax.imageio.**
-dontwarn javax.swing.**
-dontwarn org.apache.poi.**
-dontwarn org.apache.xmlbeans.**
-dontwarn org.openxmlformats.schemas.**
-dontwarn org.apache.logging.log4j.**
-dontwarn com.fasterxml.aalto.**
-dontwarn org.codehaus.stax2.**
-dontwarn javax.xml.stream.**

# Google ML Kit
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
